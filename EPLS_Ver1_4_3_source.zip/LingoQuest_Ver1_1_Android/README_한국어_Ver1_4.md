# Easy Peasy Lemon Speak (EPLS) Ver1.4 — 무료 Gemma 4 음성 대화

## 이 버전의 범위

- 갤럭시탭 S10/갤럭시 스마트폰(Android)을 위한 **Gemma 4 E2B** 로컬 자유 회화 개발판.
- 기존 전면 카메라·Android on-device 영어/한국어 음성 인식·오프라인 영어 TTS 유지.
- 영어로 말하기/텍스트 입력 → **Gemma가 새 영어 답변 생성** → 영어 음성 재생.
- 한국어로 말하기/텍스트 입력 → 같은 기기의 Gemma가 **한국어를 자연스러운 영어 문장으로 번역** → 영어 답변 생성 → 음성 재생.
- **'이 답변 한국어 해석'** 버튼을 누르면 해당 AI 영어 답변만 한국어로 번역.
- 앱을 닫기 전까지 앞선 대화를 기억하며 이어가기; '새로운 대화 시작'으로 초기화.
- 학습 교재, 보상·아이템, 발음 점수, 클라우드 동기화는 이 버전에 포함되지 않음.

## 설치 전 필독

1. APK 안에 **약 2.58GB의 모델 데이터는 없음**. 첫 실행 시 Wi-Fi로 공용 모델을 다운로드해야 합니다. 여유 공간 3.3GB 이상 권장.
2. 모델: LiteRT Community `litert-community/gemma-4-E2B-it-litert-lm` 공개 `.litertlm` 파일.
3. Google의 LiteRT-LM `0.18.0`으로 기기 **CPU** 추론. 실제 갤럭시탭 S10의 속도와 RAM 호환성은 기기 테스트 필요.
4. 음성 인식은 Android `createOnDeviceSpeechRecognizer` 사용. 기기에 오프라인 언어팩이 설치되지 않으면 마이크 대신 텍스트 입력 사용 가능. 설정에서 Google/Samsung 음성 서비스를 확인.
5. 영어 음성은 Android TextToSpeech의 오프라인 음성. 기기 영어 음성팩 필요.
6. 모델 다운받은 이후 **대화 텍스트를 외부 서버로 전송하지 않음**. 앱 인터넷 권한은 초기 Hugging Face 모델 다운로드에만 사용.
7. OpenAI 계정 연결, 유료 API, 결제, 서버 과금 코드 없음.
8. 무료라고 해서 PC/태블릿 전력 사용과 모바일 데이터 요금까지 무료라는 의미는 아닙니다. Wi-Fi 사용 권장.
9. 모델이나 STT가 불완전하면 앱은 정해진 답변을 생성형 AI인 것처럼 표시하지 않고 오류를 보여줌.

## GitHub Actions를 통한 APK 제작 (Android Studio 설치 불필요)

1. 이 ZIP (`EPLS_Ver1_4_source.zip`)을 GitHub의 기존 `LingoQuest` 저장소 루트에 **압축을 풀지 않고** 업로드.
2. `.github/workflows/build.yml`을 제공된 `EPLS_Ver1_4_build.yml` 파일 내용으로 **전체 교체**.
   - 새 설정에는 Kotlin 2.4.21 및 LiteRT-LM 의존성이 반영되어 있음.
   - `Unpack EPLS Ver1.4 source`의 명령은 정확히 `run: unzip -q EPLS_Ver1_4_source.zip`.
   - 기존 `build.yml`의 `run: run:`처럼 중복 작성하지 말 것.
3. `Commit changes` 후 GitHub `Actions`에서 가장 최신 `Build EPLS Gemma 4 APK` 작업 실행/확인.
4. 초록 체크 성공 시 `Artifacts -> EPLS-Ver1-4-Gemma4-APK`를 내려받고 ZIP 압축 해제.
5. `app-debug.apk`를 갤럭시탭에서 설치. 빨간 X라면 실패한 스텝의 자세한 에러 로그를 확인.

## 최초 실행

1. 카메라·마이크 권한을 허용하고 기존 카메라/음성 테스트를 먼저 확인.
2. '무료 AI 모델 다운로드 / 시작' 선택 후 다운로드 승인; **Wi-Fi 필요**, 약 2.6GB. 다운로드가 중단되면 다운로드 재시도.
3. 다운로드 완료 후 자동으로 CPU 모델 초기화; 상태창에 `Gemma 4 E2B 로컬 AI 준비 완료`가 떠야 성공.
4. '영어로 말하기' 모드에서 마이크에 `Hello, what do you like to do?` 말하기.
5. '한국어로 말하기' 모드에서 `오늘 학교에서 축구했어` 말하기 → 영어 표현 + 영어로 답변 확인.
6. 루미의 영어 답변 옆 `이 답변 한국어 해석`을 눌러 해석 확인.
7. 길게 대화한 뒤에는 '새로운 대화 시작'으로 문맥 리셋.

## 영구 서명키 (선택이지만 권장 — 모델을 다시 받지 않으려면 중요)

GitHub 임시 디버그 서명으로 빌드할 때마다 서명이 바뀌어 APK 충돌이 생길 수 있습니다.
기존 1.3.x에서 Ver1.4로 올릴 때 한 번은 삭제가 필요할 수 있습니다. 앱 삭제는 모델과 학습 데이터를 지웁니다.

별도로 제공된 `EPLS_Ver1_4_개인_서명키_보관.zip`의 `EPLS_SECRETS_개인보관.txt`를 열면 3개의 개인값이 있습니다.
그 값들을 GitHub 저장소 > Settings > Secrets and variables > Actions > New repository secret 에 **각각** 등록:

- `EPLS_KEYSTORE_BASE64` : 표시된 긴 Base64 문자열 전체
- `EPLS_STORE_PASS` : 표시된 비밀번호
- `EPLS_KEY_PASS` : 표시된 비밀번호 (같은 값)

**서명키 ZIP·비밀번호·Base64 문자열은 절대로 GitHub 공개 파일로 업로드하지 마세요.** 개인 보관용입니다.
그다음 workflow 재실행하면 고정키 서명 APK가 생성됩니다. 이 APK를 Ver1.4의 첫 설치로 사용하면 이후 동일 서명키와 증가하는 `versionCode`를 사용한 업데이트에서 앱 삭제 없이 설치할 수 있습니다.
키를 분실하면 덮어쓰기 업데이트가 불가능할 수 있으니 백업해 두세요.

## 현재 검증 수준과 제약

- 기존 1.2의 전면 카메라·STT·영어 TTS는 앞선 기기 테스트에서 정상 작동했음.
- Gemma 4 LiteRT-LM 실행 코드는 Google의 Android Kotlin API 문서를 따라 구현함.
- Kotlin 소스 문법 검사와 ZIP/구성 검사만 수행. **이 환경에는 Android SDK가 없어 APK 빌드 및 갤럭시탭 실기기 추론 검증은 아직 안 됨.**
- 모델 파일은 APK에 포함되지 않아 설치 직후부터 AI가 대답하는 게 아님. 다운로드와 로드가 완료되어야 함.
- 일반 음성 인식이 정확한 발음 평가와 같지는 않음. 실시간 자연스러운 대화 지연이 생길 수 있음.
- 일부 갤럭시 모델/기기 메모리 상황에선 E2B 초기화 실패 가능.

## 기술 자료

- LiteRT-LM Android: https://developers.google.com/edge/litert-lm/android
- LiteRT-LM 0.18.0: https://developer.android.com/agents/skills/device-ai/litert/litert-lm/skill
- Gemma 4 모델: https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm
