# Lingo Quest Ver1.1 — 갤럭시 전용 네이티브 Android 프로젝트

이 프로젝트는 기존 `content://` 주소로 직접 HTML을 여는 과정에서 생긴 마이크 권한 문제를 피하기 위해 WebView가 아닌 **네이티브 Android Activity**로 작성했습니다.

## 포함 기능
- 전면 셀피 카메라 실시간 미리보기: 갤럭시탭/갤럭시 스마트폰, 카메라 켜기/끄기
- 원본 픽셀 AI 선생님 캐릭터, TTS가 말할 때 입 움직임
- 마이크 권한 별도 요청, **기기 내(온디바이스) SpeechRecognizer만 사용**. 영어/한국어 선택
- 영어 음성(TTS): 가능한 경우 네트워크가 필요하지 않은 영어 목소리 선택
- 텍스트 회화, 규칙 기반 영어 답변, 회화 횟수 로컬 저장
- 영상/녹음 파일을 저장하지 않으며 앱은 `INTERNET` 권한을 요청하지 않음

## 중요: 아직 미구현 / 보장하지 않는 부분
- **자유 생성형 AI 영어 대화는 아직 없음.** 현재는 제한된 규칙 기반 응답입니다.
- **한국어 음성을 영어로 번역하는 기능도 아직 없음.** 한국어 원문 인식만 시도합니다.
- 문법/발음 정밀 평가, AI 수준별 커리큘럼도 후속 버전 개발 과제입니다.
- 갤럭시탭에 오프라인 한국어/영어 음성 인식 서비스·TTS 음성 데이터가 없는 경우 해당 기능은 작동하지 않습니다.
- **실제 APK를 현재 작업 환경에서 빌드/설치 테스트하지 못했습니다.** 파일은 설치용 APK가 아니라 Android Studio용 전체 소스 프로젝트입니다.

## PC의 Android Studio로 APK 빌드하는 방법
1. Android Studio(무료)와 Android SDK를 설치합니다.
2. ZIP 압축을 풀고 **`LingoQuest_Ver1_1_Android`** 폴더를 Android Studio의 **File > Open**으로 엽니다.
3. Java 17 (JDK), Gradle 8.11.1, Android Gradle Plugin 8.9.2, Android SDK Platform 35를 사용합니다.
4. 최초에는 Google Maven 및 Maven Central에서 CameraX 등 무료 라이브러리를 다운로드해야 하며, 비용이 발생하지 않습니다.
5. 필요하다면 Android Studio **Settings > Build > Gradle** 에서 Gradle 8.11.1을 지정하세요. 이 ZIP에는 Gradle Wrapper 실행용 JAR가 들어 있지 않습니다.
6. **Build > Build Bundle(s) / APK(s) > Build APK(s)** 또는 **Build > Generate App Bundles or APKs > Generate APKs**를 사용합니다(Studio 버전에 따라 메뉴명 상이).
7. 빌드가 성공하면 `app/build/outputs/apk/debug/app-debug.apk`를 갤럭시탭으로 옮겨 설치합니다. 기기의 설치 허용 권한이 필요할 수 있습니다.
8. 앱을 실행한 뒤 카메라 켜기와 마이크 시작을 눌러 각각 권한을 허용합니다.

**태블릿에서 ZIP을 다운로드하는 것만으로 APK가 설치되지는 않습니다.** 실제 APK 파일 생성은 별도의 Android 빌드 환경이 있어야 합니다.

## 테스트 권장 순서
1. 전면 카메라 ON: 내 얼굴이 영상으로 나오는지 확인. OFF 시 즉시 사라져야 함.
2. "Hello" 텍스트 보내기: 규칙 기반 영어 응답이 나오는지 확인.
3. 영어 음성 재생: 기기 내 TTS 음성 데이터가 설치된 경우 실제 스피커로 출력되는지 확인.
4. 영어 마이크: 온디바이스 인식이 설치된 경우 `Hello, how are you?` 말하기.
5. 한국어 모드: `안녕하세요` 말하기. 번역은 아직 하지 않음.

## 개인정보 및 비용
- `CAMERA`와 `RECORD_AUDIO` 권한만 요청. 인터넷·저장소 권한 없음.
- 카메라 영상과 마이크 음성은 앱이 직접 저장하거나 업로드하지 않음.
- Android 음성인식과 TTS는 기기에 설치된 별도 시스템 서비스로 동작합니다. 이 프로젝트는 인식 시 온디바이스 서비스만 선택하며 오프라인 모델이 없으면 실패를 안내합니다.
- AI API 사용료/월 결제/자체 서버비 없음. 기존 기기 전력 소비·최초 빌드 의존성 다운로드는 제외.

## PC가 없을 때: GitHub Actions를 통한 무료 APK 빌드 (선택)
GitHub 저장소에 이 소스 전체를 올릴 수 있다면 `.github/workflows/build-apk.yml`에서 무료 디버그 APK를 빌드하도록 설정해 두었습니다.
- GitHub 계정과 저장소가 필요합니다. **공개 저장소의 표준 Actions 러너는 무료**이지만 소스가 공개됩니다.
- 개인 저장소는 무료 제공량이 있지만 초과 사용량에는 과금될 수 있으므로, 0원 원칙에 맞게 Actions 사용량·예산 제한을 확인하세요.
- 저장소에서 **Actions → Build Lingo Quest debug APK → Run workflow** 실행.
- 완료 후 작업 실행 화면 아래 **Artifacts → LingoQuest-Ver1.1-debug-APK**를 내려받으면 APK 파일이 들어 있습니다.
- 이 작업 환경에서 GitHub Actions를 실제 실행/검증한 것은 아닙니다.
