# Easy Peasy Lemon Speak (EPLS) Ver1.3 — GPT 연결 실험판

작성: 2026-11-05

## 이번 버전에서 실제로 개발한 코드
- 앱 표시명 Easy Peasy Lemon Speak, Ver1.3.0, 기존 `applicationId` 유지 (기존 데이터 유지/업데이트 호환을 위한 선택)
- Ver1.2의 전면 카메라·마이크(기기 내 음성 인식)·영어 TTS·아바타 입 움직임 유지
- 앱에서 `Continue with ChatGPT` 선택 → **기기에서 직접** 시스템 브라우저 로그인 → OAuth PKCE + loopback 콜백
- 신규 오픈소스 동적 등록 (`dynamic_agent_client`), 앱별 host ID, state, nonce, JWT 서명 및 issuer/audience/nonce 검증
- 승인 토큰에 `chatgpt.tokens.use.direct`가 없으면 AI 요청 금지
- `/v1/models`에서 실제 표시 가능한 모델 slug 선택, `/v1/responses`로 텍스트 요청; `stream:true`, `store:false`
- GPT의 영어 대답을 기존 Android TTS로 재생하며 최근 12개 메시지쌍의 문맥을 요청에 포함
- 인증 토큰은 **앱 프로세스 메모리에만** 보유: 앱 재시작 시 재로그인 필요. 서버, GitHub, 파일에 토큰 저장 없음
- 별도 유료 API 키, 결제 수단, 별도 GPT 모델 공급자, 부모 계정 기록 접근 기능이 전혀 없음

**검증 범위:** 코드 작성 및 정적 구조 점검만 완료. Android SDK/갤럭시 실기기에서 빌드·계정 인증·서버 응답을 아직 테스트하지 못했습니다. 공식 SIWC는 기능과 가입 자격에 제한이 있습니다. 무료 계정은 로그인에 성공해도 GPT 사용 권한이 없을 수 있습니다.

## 중요한 요금 주의

EPLS 자체는 API 키를 사용하거나 별도로 결제하지 않습니다. 그러나 **ChatGPT 계정 설정에서 외부 앱이 크레딧을 사용하도록 허용한 경우**, 포함 사용량 초과 후 크레딧이 차감될 수 있습니다. EPLS는 ChatGPT 계정의 크레딧 허용 여부를 조회하거나 강제로 차단할 수 없습니다. **아들 계정에서 크레딧 사용을 비활성화한 뒤 연결**해야 하며, EPLS에서 한도 오류(HTTP 429)가 나오면 무료 대체 서비스로 자동 전환하지 않고 중단합니다.

## Github에서 APK 만들기 (Android Studio 설치 불필요)

현재 GitHub 저장소의 `LingoQuest_Ver1_1_Android` 폴더명은 이전 GitHub 빌드 스크립트와 호환을 위해 유지했습니다. 설치 앱 이름은 EPLS입니다.

1. 이 ZIP을 그대로 GitHub 저장소 **최상위**에 업로드: `EPLS_Ver1_3_source.zip`.
2. GitHub `Code → .github/workflows/build.yml`을 편집. `Unpack app source` 단계 명령을 다음으로 변경:
   `unzip -q EPLS_Ver1_3_source.zip`
3. 나머지 빌드 위치는 기존과 똑같이 유지:
   `cd LingoQuest_Ver1_1_Android && gradle :app:assembleDebug --no-daemon`
4. `Commit changes` 후 `Actions`의 새 실행 결과에서 APK를 다운로드.
5. 기존 앱과 서명이 다르면 설치 충돌이 발생할 수 있습니다. 현재는 고정 서명키 설정이 아직 완료되지 않아 최초 전환 때 삭제/재설치가 필요할 수 있습니다. 설치 전에 중요한 학습 기록을 백업하십시오. **서명을 고정하기 전에는 업데이트 시 데이터 유지가 보장되지 않습니다.**

## Ver1.3 테스트 순서

1. 앱 설치 후 전면 카메라, 영어 음성 테스트를 먼저 확인합니다.
2. ChatGPT 연결을 누르면 시스템 브라우저가 열립니다. **반드시 아들 본인의 계정**을 선택합니다.
3. 가입·OAuth 승인 화면에서 `Easy Peasy Lemon Speak` 앱명과 권한을 확인합니다.
4. 앱으로 복귀해 사용 가능한 모델이 표시되는지 확인합니다.
5. `I went to the park yesterday.` 라고 말하면 새 영어 답변을 듣는지 확인합니다.
6. `나는 어제 학교에 갔어` 를 한국어 모드에서 말하면 영어 답변을 만드는지 확인합니다.
7. 로그아웃을 누르면 연결과 대화 메모리가 즉시 초기화됩니다.

## 알려진 제약
- **GPT OAuth는 아직 실기기 검증 전**: Android 시스템 브라우저가 `127.0.0.1` loopback 콜백으로 정상 복귀하는지 확인해야 합니다.
- 앱 재시작 시 인증 토큰이 메모리에서 사라지므로 다시 로그인해야 합니다.
- 기기 내 음성 인식 엔진의 지원 여부는 태블릿 설정/언어팩에 따라 다릅니다.
- 부모 채팅/기억/파일을 조회하는 어떤 엔드포인트도 사용하지 않습니다.
- 영어 학습 전문 발음 채점이나 영상 저장, 실시간 GPT 음성 API는 아직 구현하지 않았습니다.
- EPLS 앱의 모델 목록은 **자격 여부를 확정하는 수단이 아니며**, 실제 GPT 요청 성공이 사용 가능 여부를 확인합니다.
- 이번 시험 버전은 인증 토큰을 로컬 영구 저장하지 않습니다. 장기 운영 시 Android Keystore를 사용한 보안 저장 및 토큰 갱신 로직이 필요합니다.

## 참고 공식 문서
- https://developers.openai.com/siwc/token-sharing-open-source/sign-in
- https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference
- https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations
- https://openai.com/policies/sign-in-with-chatgpt-terms/
