package com.lingoquest.personal;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import android.speech.tts.Voice;

/**
 * Easy Peasy Lemon Speak Ver1.3 — experimental ChatGPT OAuth tutor.
 * Camera and microphone recordings are not stored by EPLS.
 * Only recognized text and short dialogue context go to OpenAI on user request.
 * No billed API key, no parental ChatGPT credentials, and no local rule-based AI fallback.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(15, 21, 40);
    private static final int PANEL = Color.rgb(31, 41, 72);
    private static final int TEXT = Color.rgb(245, 248, 255);
    private static final int MUTED = Color.rgb(181, 197, 225);
    private static final int AQUA = Color.rgb(147, 238, 220);
    private static final int PURPLE = Color.rgb(169, 159, 242);

    private FrameLayout cameraBox;
    private PreviewView previewView;
    private TextView cameraPlaceholder;
    private TextView cameraToggle;
    private TextView status;
    private TextView ttsStatus;
    private TextView turnCounter;
    private LinearLayout transcriptList;
    private ScrollView transcriptScroll;
    private EditText input;
    private TeacherAvatarView avatar;
    private TextView audioToggle;
    private TextView speedToggle;
    private TextView languageToggle;
    private boolean cameraEnabled = false;
    private boolean autoSpeak = true;
    private boolean speakReady = false;
    private boolean isListening = false;
    private boolean koreanInput = false;
    private boolean ttsReady = false;
    private boolean speakTestAfterInit = false;
    private float speed = 1.0f;
    private int turns = 0;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private ProcessCameraProvider cameraProvider;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ActivityResultLauncher<String> cameraPermission;
    private ActivityResultLauncher<String> micPermission;
    private ChatGptSession chatGpt;
    private TextView loginButton;
    private TextView modelStatus;
    private final ArrayList<String[]> dialogue = new ArrayList<>();
    private boolean generating = false;

    private int dp(float value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private GradientDrawable bg(int fill, int radiusDp) {
        GradientDrawable b = new GradientDrawable(); b.setColor(fill);
        b.setCornerRadius(dp(radiusDp)); b.setStroke(dp(1), Color.rgb(60, 75, 113));
        return b;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(size);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)); }
    private LinearLayout.LayoutParams weighted(float weight) {return new LinearLayout.LayoutParams(0, -2, weight);}
    private TextView button(String label, int color) {
        TextView v = text(label, 13, TEXT, true); v.setGravity(Gravity.CENTER);
        v.setBackground(bg(color,14)); pad(v,12,10,12,10); v.setClickable(true); v.setFocusable(true);
        return v;
    }
    private void mark(String s) { status.setText(s); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        cameraPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) enableCamera(); else mark("카메라 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        micPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) beginRecognition(); else mark("마이크 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        turns = getPreferences(MODE_PRIVATE).getInt("turns",0);
        chatGpt = new ChatGptSession(this, new ChatGptSession.Callback() {
            @Override public void onStatus(String message) { runOnUiThread(() -> { if(modelStatus!=null) modelStatus.setText(message); }); }
            @Override public void onReady(String modelName) { runOnUiThread(() -> {
                if(modelStatus!=null) modelStatus.setText("🔐 계정 인증 및 모델 목록 확인 · 답변 검증 전 · " + modelName);
                if(loginButton!=null) loginButton.setText("ChatGPT 연결 해제");
                mark("계정 연결됨 · 실제 GPT 답변 생성 여부를 시험해 줘.");
            }); }
            @Override public void onError(String message) { runOnUiThread(() -> {
                if(modelStatus!=null) modelStatus.setText("⚠ " + message);
                if(loginButton!=null) loginButton.setText("Continue with ChatGPT");
                generating=false;
                mark("연결 상태를 확인해 줘. 유료 API로 전환하지 않아.");
            }); }
        });
        setupScreen(); setupTts();
        addBubble(false, "Hi! I'm Lumi. Let's practice English together!", "안녕! 나는 루미야. GPT 연결 후 영어로 이야기해 보자!");
        boolean stt = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        mark(stt ? "준비 완료 · 무료 기기 내 음성 인식을 사용할 수 있어." : "기기 내 음성 인식 서비스 확인 필요 · 텍스트 연습은 가능해.");
    }

    private void setupScreen() {
        LinearLayout screen = vertical(); screen.setBackgroundColor(BG);
        setContentView(screen);
        LinearLayout heading = horizontal(); pad(heading,18,15,18,10);
        TextView logo = text("✦  EASY PEASY LEMON SPEAK",18, TEXT, true); heading.addView(logo, weighted(1));
        TextView chip = text("EPLS · 1.3.1",10,AQUA,true); pad(chip,8,5,8,5);
        chip.setBackground(bg(PANEL,14)); heading.addView(chip); screen.addView(heading);
        ScrollView content = new ScrollView(this); content.setFillViewport(false);
        screen.addView(content, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body = vertical(); pad(body,14,4,14,15); content.addView(body);
        TextView subtitle = text("카메라 + 음성 + GPT 영어 자유 회화",13,MUTED,false);
        body.addView(subtitle,lp(-1,-2));

        // Side-by-side teacher and selfie preview (native CameraX, not WebView).
        LinearLayout scenes = horizontal(); scenes.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams scenesMargin = lp(-1,-2); scenesMargin.topMargin=dp(13); body.addView(scenes,scenesMargin);
        LinearLayout teacherCard=vertical(); teacherCard.setBackground(bg(PANEL,20)); pad(teacherCard,8,8,8,9);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0,-2,1); half.rightMargin=dp(6);
        scenes.addView(teacherCard,half);
        TextView tLabel=text("✨ AI 선생님 · 루미",13,TEXT,true);tLabel.setGravity(Gravity.CENTER);teacherCard.addView(tLabel);
        avatar=new TeacherAvatarView(this);
        teacherCard.addView(avatar,lp(-1,186));
        TextView tInfo=text("영어로 말해 줄게!",11,AQUA,true);tInfo.setGravity(Gravity.CENTER);teacherCard.addView(tInfo);
        
        LinearLayout selfieCard=vertical(); selfieCard.setBackground(bg(PANEL,20));pad(selfieCard,8,8,8,9);
        LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,-2,1);half2.leftMargin=dp(6);
        scenes.addView(selfieCard,half2);
        TextView cLabel=text("📷 내 얼굴",13,TEXT,true);cLabel.setGravity(Gravity.CENTER);selfieCard.addView(cLabel);
        cameraBox=new FrameLayout(this); cameraBox.setBackground(bg(Color.rgb(20,29,53),15));
        previewView=new PreviewView(this);previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraBox.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        cameraPlaceholder=text("◉\n전면 카메라 꺼짐\n영상은 저장하지 않아",12,MUTED,true);
        cameraPlaceholder.setGravity(Gravity.CENTER);cameraPlaceholder.setBackground(bg(Color.rgb(20,29,53),15));
        cameraBox.addView(cameraPlaceholder,new FrameLayout.LayoutParams(-1,-1));
        selfieCard.addView(cameraBox,lp(-1,186));
        cameraToggle=button("카메라 켜기",Color.rgb(68,80,121));
        LinearLayout.LayoutParams toggleLp=lp(-1,38);toggleLp.topMargin=dp(6);
        selfieCard.addView(cameraToggle,toggleLp);
        cameraToggle.setOnClickListener(v->{ if(cameraEnabled)disableCamera(); else requestCamera(); });

        LinearLayout notice=vertical();notice.setBackground(bg(Color.rgb(26,37,63),15));pad(notice,12,11,12,11);
        LinearLayout.LayoutParams noticeLp=lp(-1,-2);noticeLp.topMargin=dp(14);body.addView(notice,noticeLp);
        status=text("시스템 초기화 중",12,AQUA,true);notice.addView(status);
        ttsStatus=text("🔊 영어 음성 엔진 확인 중...",11,MUTED,false);notice.addView(ttsStatus);
        TextView privacy=text("영상/음성 파일 저장 없음 · GPT 연결 시 인식 텍스트와 최근 대화 문맥만 전송",11,MUTED,false);
        LinearLayout.LayoutParams pLp=lp(-1,-2);pLp.topMargin=dp(4);notice.addView(privacy,pLp);

        LinearLayout connectPanel=vertical();connectPanel.setBackground(bg(Color.rgb(26,43,65),15));pad(connectPanel,12,12,12,12);
        LinearLayout.LayoutParams connectParams=lp(-1,-2);connectParams.topMargin=dp(10);body.addView(connectPanel,connectParams);
        TextView title=text("🔐 아들 본인의 ChatGPT 계정 연결",14,TEXT,true);connectPanel.addView(title);
        modelStatus=text("로그인 전 · ChatGPT와 연결되지 않았어",11,MUTED,false);
        LinearLayout.LayoutParams ms=lp(-1,-2);ms.topMargin=dp(5);connectPanel.addView(modelStatus,ms);
        loginButton=button("Continue with ChatGPT",Color.rgb(47,98,116));
        LinearLayout.LayoutParams cb=lp(-1,44);cb.topMargin=dp(9);connectPanel.addView(loginButton,cb);
        loginButton.setOnClickListener(v->{
            if(chatGpt.isConnected()) {
                chatGpt.signOut(); dialogue.clear(); generating=false;
                loginButton.setText("Continue with ChatGPT");
                modelStatus.setText("연결 해제 · 이번 대화 기록도 초기화했어");
                mark("ChatGPT 연결이 해제됐어.");
            } else new AlertDialog.Builder(this)
                .setTitle("아들 본인의 ChatGPT 계정 사용")
                .setMessage("아들 계정으로만 로그인해 줘. EPLS는 별도 유료 API 키를 사용하지 않지만, ChatGPT 설정에서 외부 앱의 추가 크레딧 사용을 허용했다면 과금될 수 있어. 추가 크레딧 사용을 꺼 둔 뒤 계속해 줘.")
                .setNegativeButton("취소",(dialog,which)->{})
                .setPositiveButton("확인하고 로그인",(dialog,which)->chatGpt.startLogin())
                .show();
        });
        TextView usage=text("별도 유료 API 없음 · 크레딧 사용은 ChatGPT 설정에서 꺼야 해 · 한도 초과 시 중단",11,MUTED,false);
        LinearLayout.LayoutParams ul=lp(-1,-2);ul.topMargin=dp(6);connectPanel.addView(usage,ul);

        LinearLayout tools=horizontal();LinearLayout.LayoutParams toolsLp=lp(-1,-2);toolsLp.topMargin=dp(13);body.addView(tools,toolsLp);
        languageToggle=button("🎤 영어로 말하기",Color.rgb(53,71,111));
        LinearLayout.LayoutParams tool1=new LinearLayout.LayoutParams(0,dp(46),1);tool1.rightMargin=dp(6);tools.addView(languageToggle,tool1);
        languageToggle.setOnClickListener(v->{ koreanInput=!koreanInput;
            languageToggle.setText(koreanInput?"🎤 한국어로 말하기":"🎤 영어로 말하기");
            mark(koreanInput?"마이크 언어: 한국어 · GPT가 영어로 답해 줄 거야":"마이크 언어: 영어");
        });
        TextView speakBtn=button("● 마이크 시작",Color.rgb(108,77,143));
        LinearLayout.LayoutParams tool2=new LinearLayout.LayoutParams(0,dp(46),1);tool2.leftMargin=dp(6);tools.addView(speakBtn,tool2);
        speakBtn.setOnClickListener(v->{ if(isListening){ stopRecognition();mark("듣기를 중지했어."); } else requestMicrophone(); });
        
        LinearLayout settings=horizontal(); LinearLayout.LayoutParams sp=lp(-1,-2);sp.topMargin=dp(9);body.addView(settings,sp);
        audioToggle=button("🔊 자동 읽기 켜짐",Color.rgb(48,63,97));
        LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(0,dp(39),1);sb.rightMargin=dp(5);settings.addView(audioToggle,sb);
        audioToggle.setOnClickListener(v->{autoSpeak=!autoSpeak;audioToggle.setText(autoSpeak?"🔊 자동 읽기 켜짐":"🔈 자동 읽기 꺼짐");});
        speedToggle=button("속도: 보통",Color.rgb(48,63,97));
        LinearLayout.LayoutParams sb2=new LinearLayout.LayoutParams(0,dp(39),1);sb2.leftMargin=dp(5);settings.addView(speedToggle,sb2);
        speedToggle.setOnClickListener(v->{speed=(speed==1.0f)?0.8f:1.0f;
            speedToggle.setText(speed<1?"속도: 느리게":"속도: 보통");});
        TextView soundTest=button("🔊 영어 음성 테스트 / 엔진 재확인",Color.rgb(50,104,114));
        LinearLayout.LayoutParams stp=lp(-1,42);stp.topMargin=dp(8);body.addView(soundTest,stp);
        soundTest.setOnClickListener(v->{
            if(ttsReady) speak("Hello! I am Lumi. Can you hear my voice?");
            else setupTts(true);
        });
        
        LinearLayout chatHead=horizontal();LinearLayout.LayoutParams cp=lp(-1,-2);cp.topMargin=dp(18);body.addView(chatHead,cp);
        TextView chatLabel=text("💬 영어 대화",18,TEXT,true);chatHead.addView(chatLabel,weighted(1));
        turnCounter=text("연습 "+turns+"회",12,AQUA,true);chatHead.addView(turnCounter);
        transcriptScroll=new ScrollView(this);transcriptScroll.setFillViewport(true);
        LinearLayout.LayoutParams scrollLp=lp(-1,260);scrollLp.topMargin=dp(9);body.addView(transcriptScroll,scrollLp);
        transcriptList=vertical();pad(transcriptList,10,10,10,10);
        transcriptList.setBackground(bg(Color.rgb(22,30,53),18));transcriptScroll.addView(transcriptList);
        
        TextView demoLabel=text("Ver1.3.1 · GPT 계정 연결 후에만 자유 대화 · 대화 내용은 앱 종료 시 유지되지 않아.",11,MUTED,false);
        LinearLayout.LayoutParams dl=lp(-1,-2);dl.topMargin=dp(9);body.addView(demoLabel,dl);
        
        LinearLayout composer=horizontal();pad(composer,12,10,12,13);
        composer.setBackgroundColor(Color.rgb(20,28,49));screen.addView(composer);
        input=new EditText(this);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setTextSize(14);
        input.setSingleLine(false);input.setMaxLines(2);input.setHint("영어 또는 한국어로 입력...");
        input.setBackground(bg(PANEL,14));pad(input,12,9,12,9);
        LinearLayout.LayoutParams inputLp=new LinearLayout.LayoutParams(0,dp(54),1);inputLp.rightMargin=dp(8);
        composer.addView(input,inputLp);
        TextView send=button("보내기 ➜",Color.rgb(40,130,119));composer.addView(send,lp(90,54));
        send.setOnClickListener(v->{String s=input.getText().toString().trim();if(!s.isEmpty()){input.setText("");handleUser(s);} });
    }

    private void addBubble(boolean me,String english,String korean) {
        LinearLayout wrap=vertical();
        LinearLayout.LayoutParams wp=lp(-1,-2);wp.bottomMargin=dp(9);
        wrap.setBackground(bg(me?Color.rgb(51,51,94):PANEL,13));pad(wrap,12,10,12,10);
        TextView from=text(me?"나":"루미 선생님",11,me?PURPLE:AQUA,true);wrap.addView(from);
        TextView main=text(english,16,TEXT,false);LinearLayout.LayoutParams mp=lp(-1,-2);mp.topMargin=dp(3);wrap.addView(main,mp);
        if(korean!=null&&!korean.isEmpty()) {TextView trans=text(korean,12,MUTED,false);wrap.addView(trans);}
        transcriptList.addView(wrap,wp);
        transcriptScroll.post(()->transcriptScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void handleUser(String message) {
        if(!chatGpt.isConnected()) {
            mark("먼저 위의 'Continue with ChatGPT' 버튼으로 아들 계정에 로그인해 줘.");
            return;
        }
        if(generating) {mark("GPT가 답변을 작성 중이야. 답변이 나온 후 다시 말해 줘.");return;}
        final boolean korean=message.matches(".*[가-힣].*");
        addBubble(true,message,korean?"한국어 원문 텍스트":"음성 인식/입력 원문");
        turns++;getPreferences(MODE_PRIVATE).edit().putInt("turns",turns).apply();turnCounter.setText("연습 "+turns+"회");
        generating = true;
        mark("실제 GPT가 영어 답변을 생성 중…");
        JSONArray messages=new JSONArray();
        int first=Math.max(0,dialogue.size()-12);
        for(int i=first;i<dialogue.size();i++){
            String[] t=dialogue.get(i);
            try{messages.put(new JSONObject().put("role",t[0]).put("content",t[1]));}
            catch(Exception ignored){}
        }
        try{messages.put(new JSONObject().put("role","user").put("content",message));}
        catch(Exception ignored){}
        chatGpt.generate(messages, reply -> runOnUiThread(() -> {
            generating=false;
            if(reply==null || reply.trim().isEmpty()) {
                mark("GPT 답변을 읽지 못했어. 유료 서비스로 전환하지 않아.");return;
            }
            dialogue.add(new String[]{"user",message});
            dialogue.add(new String[]{"assistant",reply});
            if(dialogue.size()>24) dialogue.subList(0,dialogue.size()-24).clear();
            addBubble(false,reply,"GPT가 새로 생성한 영어 답변");
            mark("GPT 답변 생성 검증 성공 · 영어 음성 출력");
            if(modelStatus!=null) modelStatus.setText("✅ 실제 GPT 응답 검증 완료");
            if(autoSpeak)speak(reply);
        }), error -> runOnUiThread(() -> {
            generating=false;
            mark("GPT 답변 실패: "+error+" · 추가 결제 없이 요청 중단");
        }));
    }

    private void updateTtsStatus(String message) {
        runOnUiThread(() -> { if (ttsStatus != null) ttsStatus.setText(message); });
    }
    private void setupTts() { setupTts(false); }
    private void setupTts(boolean testAfterInit) {
        // Allow changing the system TTS engine or downloading English voice data
        // without reinstalling the application.
        speakTestAfterInit = testAfterInit;
        ttsReady = false;
        updateTtsStatus("🔊 영어 음성 엔진 확인 중...");
        if(tts != null) {
            try { tts.stop(); tts.shutdown(); } catch(Exception ignored) {}
            tts = null;
        }
        tts = new TextToSpeech(this, result -> {
            if(result != TextToSpeech.SUCCESS || tts == null) {
                updateTtsStatus("❌ TTS 초기화 실패 · 설정 > 일반 > 글자 읽어주기에서 엔진을 확인해 줘.");
                return;
            }
            int lang = tts.setLanguage(Locale.US);
            if(lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                updateTtsStatus("❌ 영어 음성 데이터가 없어. 글자 읽어주기 > 음성 데이터 설치 > 영어(미국)");
                return;
            }
            // Avoid rejecting the engine simply because getVoices() is empty.
            // Prefer an offline American English voice, then any offline English
            // voice. If the system default is already offline, keep it.
            Voice best = null;
            Set<Voice> voices = tts.getVoices();
            if(voices != null) {
                for(Voice v : voices) {
                    if(v == null || v.isNetworkConnectionRequired() || v.getLocale() == null) continue;
                    if(!"en".equals(v.getLocale().getLanguage())) continue;
                    if(best == null || ("US".equals(v.getLocale().getCountry()) &&
                            !"US".equals(best.getLocale().getCountry()))) best = v;
                }
            }
            String voiceInfo = "기본 영어 음성";
            if(best != null) {
                if(tts.setVoice(best) == TextToSpeech.SUCCESS) voiceInfo = "오프라인 영어 음성";
            }
            Voice selected = tts.getVoice();
            if(selected != null && selected.isNetworkConnectionRequired()) {
                updateTtsStatus("❌ 현재 영어 목소리는 인터넷이 필요해. 무료 오프라인 영어 음성 데이터를 설치해 줘.");
                return;
            }
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(true); updateTtsStatus("🔊 영어 음성 재생 중..."); });
                }
                @Override public void onDone(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(false); updateTtsStatus("✅ 영어 음성 재생 완료"); });
                }
                @Override public void onError(String id) { showTtsError("엔진 출력 오류"); }
                @Override public void onError(String id, int code) { showTtsError("엔진 오류 코드 " + code); }
                private void showTtsError(String detail) {
                    runOnUiThread(() -> {
                        avatar.setSpeaking(false);
                        updateTtsStatus("❌ 영어 음성 실패: " + detail + " · 영어 데이터/미디어 음량을 확인해 줘.");
                    });
                }
            });
            ttsReady = true;
            AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if(am != null && am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
                updateTtsStatus("⚠️ 미디어 음량이 0이야. 볼륨 버튼으로 올려 줘.");
            } else {
                updateTtsStatus("✅ " + voiceInfo + " 준비 완료 · 아래 '영어 음성 테스트'를 눌러 봐.");
            }
            if(speakTestAfterInit) {
                speakTestAfterInit = false;
                runOnUiThread(() -> speak("Hello! I am Lumi. Can you hear my voice?"));
            }
        });
    }
    private void speak(String sentence) {
        if(!ttsReady || tts == null) {
            updateTtsStatus("❌ TTS가 준비되지 않았어. 영어 음성 테스트/엔진 재확인을 눌러 줘.");
            return;
        }
        tts.setSpeechRate(speed);
        int result = tts.speak(sentence, TextToSpeech.QUEUE_FLUSH, null,
                "lumi_"+System.currentTimeMillis());
        if(result == TextToSpeech.ERROR) {
            updateTtsStatus("❌ TTS 음성 요청 실패 · 글자 읽어주기 설정에서 영어(미국)를 확인해 줘.");
        }
    }
    private void requestCamera(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)enableCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }
    private void enableCamera() {
        cameraEnabled=true;cameraToggle.setText("카메라 끄기");cameraPlaceholder.setVisibility(View.GONE);
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(!cameraEnabled)return;
            try{
                cameraProvider=future.get();cameraProvider.unbindAll();
                Preview preview=new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview);
                mark("내 얼굴 표시 중 · 영상 저장 없음");
            }catch(Exception e){cameraEnabled=false;cameraPlaceholder.setVisibility(View.VISIBLE);
                cameraToggle.setText("카메라 켜기");mark("전면 카메라 시작 실패: "+e.getClass().getSimpleName());}
        },ContextCompat.getMainExecutor(this));
    }
    private void disableCamera(){cameraEnabled=false;if(cameraProvider!=null)cameraProvider.unbindAll();
        cameraPlaceholder.setVisibility(View.VISIBLE);cameraToggle.setText("카메라 켜기");mark("카메라 꺼짐 · 영상 저장 없음");}

    private void requestMicrophone(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)beginRecognition();
        else micPermission.launch(Manifest.permission.RECORD_AUDIO);
    }
    private void beginRecognition(){
        if(Build.VERSION.SDK_INT<31||!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
            mark("오프라인 음성 인식이 설치되지 않았어. 기기 음성 서비스/언어팩을 확인해 줘.");return;
        }
        stopRecognition();
        try{
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle p){mark("듣고 있어… 문장을 말해 줘.");}
                @Override public void onBeginningOfSpeech(){mark("음성 인식 중…");}
                @Override public void onRmsChanged(float r){}
                @Override public void onBufferReceived(byte[] b){}
                @Override public void onEndOfSpeech(){mark("음성을 텍스트로 변환 중…");}
                @Override public void onError(int code){
                    isListening=false;String suffix=code==SpeechRecognizer.ERROR_NO_MATCH?"음성을 알아듣지 못했어.":
                        code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"말소리가 들리지 않았어.":
                        code==SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE?"해당 언어 모델이 설치되지 않았어.":
                        "인식 오류 코드 "+code;
                    mark(suffix+" 다시 시도하거나 텍스트를 입력해 줘.");
                    disposeRecognizer();
                }
                @Override public void onResults(Bundle b){
                    isListening=false;ArrayList<String> result=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(result!=null&&!result.isEmpty())handleUser(result.get(0));
                    else mark("음성 인식 결과가 없어. 다시 말해 줘.");
                    disposeRecognizer();
                }
                @Override public void onPartialResults(Bundle b){}
                @Override public void onEvent(int type, Bundle p){}
            });
            Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,koreanInput?"ko-KR":"en-US");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
            isListening=true;recognizer.startListening(intent);
        }catch(Exception e){isListening=false;disposeRecognizer();mark("마이크 시작 실패: "+e.getMessage());}
    }
    private void stopRecognition(){isListening=false;if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}}
    private void disposeRecognizer(){if(recognizer!=null){try{recognizer.destroy();}catch(Exception ignored){}recognizer=null;}}
    @Override protected void onResume(){super.onResume();if(cameraEnabled&&cameraProvider!=null)enableCamera();}
    @Override protected void onPause(){super.onPause();if(cameraProvider!=null)cameraProvider.unbindAll();stopRecognition();if(tts!=null)tts.stop();avatar.setSpeaking(false);}
    @Override protected void onDestroy(){disableCamera();stopRecognition();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
