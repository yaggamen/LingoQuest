package com.lingoquest.personal;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Experimental SIWC open-source direct OAuth client for EPLS on Android.
 * Credentials are held IN MEMORY ONLY; only non-secret host/client IDs persist.
 * No parent account data, no ChatGPT conversations or memories, no API keys.
 * Security: OAuth state+PKCE+OIDC RS256/JWKS signature, issuer/audience/nonce.
 * This class has not yet been tested with an actual SIWC account on Galaxy Tab.
 */
public final class ChatGptSession {
    public interface Callback {
        void onStatus(String msg);
        void onReady(String modelName);
        void onError(String msg);
    }
    private static final String AUTH = "https://auth.openai.com/api/accounts/authorize";
    private static final String TOKEN = "https://auth.openai.com/api/accounts/oauth/token";
    private static final String RESOURCE = "https://api.openai.com/v1";
    private static final String ISSUER = "https://auth.openai.com";
    private static final String SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct";
    private static final String REDIRECT_PATH = "/auth/callback";
    private static final String INSTRUCTIONS =
        "You are Lumi, a warm, age-appropriate English conversation tutor in Easy Peasy Lemon Speak (EPLS). " +
        "The learner is a teenager. Converse naturally, not by scripts. " +
        "Answer in natural clear English, normally in 1-3 short sentences, then ask one meaningful follow-up question. " +
        "Understand Korean messages and usually respond in accessible English; if the learner explicitly requests a Korean explanation, briefly explain in Korean. " +
        "Gently correct significant English mistakes without interrupting the conversational flow; don't overcorrect every sentence. " +
        "Do not ask for private identity, contact information or addresses. " +
        "You have NO access to the parent's ChatGPT account, history, files or memories. " +
        "Don't claim access to them. Do not reference personal details not present in this conversation. " +
        "Do not include audio markup, markdown tables, or stage directions; your response will be read aloud by Android TTS.";

    private final Activity activity;
    private final Callback callback;
    private final SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SecureRandom random = new SecureRandom();
    private volatile String accessToken;
    private volatile String selectedModel;
    private volatile long expiry;
    private volatile boolean connecting;
    private volatile int sessionEpoch;

    public ChatGptSession(Activity activity, Callback callback) {
        this.activity=activity;
        this.callback=callback;
        this.prefs=activity.getSharedPreferences("epls_auth_identifiers", Activity.MODE_PRIVATE);
        if(prefs.getString("host",null)==null) {
            prefs.edit().putString("host","urn:uuid:"+UUID.randomUUID()).apply();
        }
    }
    private void status(String s) {main.post(()->callback.onStatus(s));}
    private void failure(String s) {main.post(()->callback.onError(s));}
    public boolean isConnected() {return accessToken!=null && selectedModel!=null && System.currentTimeMillis()<expiry-120000;}
    public void signOut() {
        accessToken=null;selectedModel=null;expiry=0;connecting=false;sessionEpoch++;
        // Explicit sign-out removes the account's dynamic client registration locally.
        prefs.edit().remove("client_id").remove("sub").apply();
        status("계정 연결 해제 · 인증 정보는 저장되지 않았어");
    }

    public synchronized void startLogin() {
        if(connecting) {status("로그인을 진행 중이야.");return;}
        if(isConnected()) {status("이미 ChatGPT에 연결됐어.");return;}
        connecting=true;
        status("보안 로그인 시작 · ChatGPT 계정 권한 확인 중");
        new Thread(()->{
            ServerSocket server=null;
            try {
                String state=secret(32), nonce=secret(32), verifier=secret(48);
                String challenge=urlB64(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
                String client=prefs.getString("client_id",null);
                if(client==null || client.isEmpty())client="dynamic_agent_client";
                server=new ServerSocket(0,1,InetAddress.getByName("127.0.0.1"));
                server.setSoTimeout(180000);
                String redirect="http://127.0.0.1:"+server.getLocalPort()+REDIRECT_PATH;
                StringBuilder link=new StringBuilder(AUTH).append('?');
                param(link,"client_id",client);param(link,"response_type","code");
                param(link,"redirect_uri",redirect);param(link,"scope",SCOPES);
                param(link,"resource",RESOURCE);param(link,"ext_agent_host_id",prefs.getString("host",""));
                param(link,"state",state);param(link,"nonce",nonce);
                param(link,"code_challenge_method","S256");param(link,"code_challenge",challenge);
                if("dynamic_agent_client".equals(client))param(link,"agent_name_hint","Easy Peasy Lemon Speak");
                final String requestedClient=client;
                final ServerSocket listener=server;
                main.post(()->{
                    try {activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(link.toString())));}
                    catch(Exception e) {failure("인터넷 브라우저를 열지 못했어.");try{listener.close();}catch(Exception ignored){}}
                });
                Map<String,String> callbackParams=waitCallback(server);
                if(!state.equals(callbackParams.get("state"))) throw new Exception("OAuth state 검증 실패");
                if(callbackParams.containsKey("error"))throw new Exception("사용자가 로그인을 취소했거나 권한이 거부됐어.");
                String code=callbackParams.get("code");
                if(code==null || code.isEmpty())throw new Exception("로그인 승인 코드가 없어.");
                String callbackClient=callbackParams.get("client_id");
                if("dynamic_agent_client".equals(requestedClient)) {
                    if(callbackClient==null || !callbackClient.startsWith("oaiapp_"))throw new Exception("클라이언트 등록이 완료되지 않았어.");
                    client=callbackClient;
                    // Save only public client ID, allowing retry if code expires.
                    prefs.edit().putString("client_id",client).apply();
                } else if(callbackClient!=null && !callbackClient.equals(requestedClient)){
                    throw new Exception("등록된 클라이언트와 일치하지 않아.");
                }
                status("계정 확인 중 · 인증 서명을 검증하고 있어");
                JSONObject token=postForm(TOKEN,form(
                    "grant_type","authorization_code", "client_id",client,
                    "code",code, "code_verifier",verifier,
                    "redirect_uri",redirect,"resource",RESOURCE));
                String idToken=token.optString("id_token","");
                if(idToken.isEmpty())throw new Exception("검증 가능한 계정 토큰이 없어.");
                JSONObject identity=verifyIdToken(idToken,client,nonce);
                String subject=identity.optString("sub","");
                String previous=prefs.getString("sub",null);
                if(previous!=null && !previous.equals(subject))throw new Exception("기존 EPLS 사용자와 다른 계정이야. 로그아웃 후 새로 연결해 줘.");
                String scopes=token.optString("scope","");
                if(!hasScope(scopes,"chatgpt.tokens.use.direct"))throw new Exception("GPT 사용 권한이 승인되지 않았어. 로그인만으로는 사용 불가해.");
                String newAccess=token.optString("access_token","");
                if(newAccess.isEmpty())throw new Exception("GPT 연결 토큰이 없어.");
                status("GPT 사용 가능한 모델 확인 중…");
                String model=loadFirstModel(newAccess);
                if(model==null)throw new Exception("사용 가능한 GPT 모델이 검색되지 않았어.");
                prefs.edit().putString("sub",subject).apply();
                accessToken=newAccess;
                selectedModel=model;
                expiry=System.currentTimeMillis()+Math.max(300,token.optLong("expires_in",3600))*1000;
                final String finalModel=model; // Never expose the child account email in screenshots/status text.
                main.post(()->callback.onReady(finalModel));
            }catch(Exception e){
                accessToken=null;selectedModel=null;
                failure(shortError(e));
            }finally{
                connecting=false;
                if(server!=null)try{server.close();}catch(Exception ignored){}
            }
        },"epls-oauth").start();
    }

    public void generate(JSONArray messages, Consumer<String> done, Consumer<String> error) {
        if(!isConnected()) {error.accept("ChatGPT 로그인이 필요하거나 연결이 만료됐어.");return;}
        final String token=accessToken, model=selectedModel;
        final int requestEpoch=sessionEpoch;
        new Thread(()->{
            HttpURLConnection conn=null;
            try {
                JSONObject request=new JSONObject();
                request.put("model",model);
                request.put("instructions",INSTRUCTIONS);
                request.put("input",messages);
                request.put("store",false);
                request.put("stream",true);
                conn=(HttpURLConnection)new URL(RESOURCE+"/responses").openConnection();
                conn.setRequestMethod("POST");conn.setConnectTimeout(15000);conn.setReadTimeout(90000);
                conn.setDoOutput(true);conn.setRequestProperty("Authorization","Bearer "+token);
                conn.setRequestProperty("Content-Type","application/json");
                conn.setRequestProperty("Accept","text/event-stream");
                try(OutputStream out=conn.getOutputStream()){
                    out.write(request.toString().getBytes(StandardCharsets.UTF_8));
                }
                int rc=conn.getResponseCode();
                if(rc!=200){
                    String errorCode="";
                    try {
                        InputStream errorStream=conn.getErrorStream();
                        if(errorStream!=null){
                            JSONObject body=new JSONObject(read(errorStream));
                            JSONObject err=body.optJSONObject("error");
                            if(err!=null)errorCode=err.optString("code", "");
                            if(errorCode.isEmpty())errorCode=body.optString("code", "");
                        }
                    }catch(Exception ignored) { /* No raw body or credential logging. */ }
                    throw new Exception(meaningfulError(errorCode,rc));
                }
                StringBuilder text=new StringBuilder();
                boolean complete=false;
                try(BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream(),StandardCharsets.UTF_8))){
                    String line;
                    while((line=reader.readLine())!=null){
                        if(!line.startsWith("data: "))continue;
                        String data=line.substring(6).trim();
                        if(data.isEmpty()||"[DONE]".equals(data))continue;
                        JSONObject event;
                        try{event=new JSONObject(data);}catch(Exception ignored){continue;}
                        String type=event.optString("type","");
                        if("response.output_text.delta".equals(type))text.append(event.optString("delta",""));
                        if("response.failed".equals(type)||"error".equals(type)) {
                            JSONObject detail=event.optJSONObject("response");
                            JSONObject err=detail!=null?detail.optJSONObject("error"):null;
                            if(err==null)err=event.optJSONObject("error");
                            String errorCode=err==null?event.optString("code",""):err.optString("code","");
                            throw new Exception(meaningfulError(errorCode,200));
                        }
                        if("response.incomplete".equals(type))throw new Exception("GPT 응답이 중간에 중단됐어 (response.incomplete).");
                        if("response.completed".equals(type))complete=true;
                    }
                }
                if(!complete || text.length()==0)throw new Exception("GPT 응답이 정상적으로 완료되지 않았어.");
                if(requestEpoch==sessionEpoch)done.accept(text.toString().trim());
            }catch(Exception e){if(requestEpoch==sessionEpoch)error.accept(shortError(e));}
            finally{if(conn!=null)conn.disconnect();}
        },"epls-gpt-request").start();
    }

    // Present only a bounded error code, never access tokens, response bodies, or user text.
    private static String meaningfulError(String errorCode,int httpStatus){
        String code=errorCode==null?"":errorCode.replaceAll("[^A-Za-z0-9_.-]","");
        if(code.length()>100)code=code.substring(0,100);
        if("subscription_sharing_usage_limit_exceeded".equals(code))
            return "계정 또는 EPLS 사용량 한도 초과 ("+code+"). 추가 결제 없이 중단했어.";
        if("subscription_sharing_user_not_eligible".equals(code))
            return "이 계정은 EPLS의 ChatGPT 사용 대상이 아니야 ("+code+").";
        if("subscription_sharing_usage_unavailable".equals(code))
            return "사용량 확인 서버가 일시적으로 응답하지 않아 ("+code+"). 자동 유료 전환 없음.";
        if(!code.isEmpty())return "GPT 요청 오류: "+code+" (HTTP "+httpStatus+")";
        return "GPT 요청 오류: 세부 코드 없음 (HTTP "+httpStatus+").";
    }

    private String loadFirstModel(String bearer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(RESOURCE+"/models").openConnection();
        try {
            c.setConnectTimeout(15000);c.setReadTimeout(20000);
            c.setRequestProperty("Authorization","Bearer "+bearer);
            if(c.getResponseCode()!=200)throw new Exception("사용 가능한 모델 목록을 확인할 수 없어 (HTTP "+c.getResponseCode()+")");
            JSONObject json=new JSONObject(read(c.getInputStream()));
            JSONArray list=json.optJSONArray("models");
            if(list==null)list=json.optJSONArray("data");
            if(list==null)throw new Exception("모델 목록이 비어 있어.");
            for(int i=0;i<list.length();i++){
                JSONObject model=list.optJSONObject(i);
                if(model==null)continue;
                if(!"list".equals(model.optString("visibility","")))continue;
                String slug=model.optString("slug",model.optString("id",""));
                if(!slug.isEmpty())return slug;
            }
            return null;
        }finally{c.disconnect();}
    }

    private JSONObject verifyIdToken(String raw,String client,String expectedNonce) throws Exception {
        String[] parts=raw.split("\\.");
        if(parts.length!=3)throw new Exception("ID 토큰 형식 오류");
        JSONObject header=new JSONObject(new String(Base64.decode(parts[0],Base64.URL_SAFE|Base64.NO_WRAP),StandardCharsets.UTF_8));
        JSONObject claims=new JSONObject(new String(Base64.decode(parts[1],Base64.URL_SAFE|Base64.NO_WRAP),StandardCharsets.UTF_8));
        if(!"RS256".equals(header.optString("alg")))throw new Exception("지원되지 않는 계정 서명 방식");
        if(!ISSUER.equals(claims.optString("iss")))throw new Exception("계정 발급자 검증 실패");
        if(!expectedNonce.equals(claims.optString("nonce")))throw new Exception("계정 재생 공격 방지 검증 실패");
        if(!audienceMatches(claims.opt("aud"),client))throw new Exception("앱 연결 대상 검증 실패");
        long now=System.currentTimeMillis()/1000;
        if(claims.optLong("exp",0)<=now || claims.optLong("iat",0)<=0 || claims.optLong("iat",0)>now+120)throw new Exception("계정 인증 시간이 올바르지 않아.");
        if(claims.optLong("nbf",0)>now+120)throw new Exception("인증 유효 시간이 아직 시작되지 않았어.");
        if(claims.optString("sub","").isEmpty())throw new Exception("계정 ID가 없어.");
        JSONObject discovery=getJson("https://auth.openai.com/.well-known/openid-configuration",null);
        String jwksUri=discovery.optString("jwks_uri","");
        if(!jwksUri.startsWith("https://auth.openai.com/"))throw new Exception("인증 키 제공 주소 검증 실패");
        if(!ISSUER.equals(discovery.optString("issuer", "")))throw new Exception("OIDC 설정 발급자 검증 실패");
        JSONArray keys=getJson(jwksUri,null).getJSONArray("keys");
        String kid=header.optString("kid","");
        boolean good=false;
        for(int i=0;i<keys.length();i++){
            JSONObject key=keys.getJSONObject(i);
            if(!kid.equals(key.optString("kid"))||!"RSA".equals(key.optString("kty")))continue;
            byte[] n=Base64.decode(key.getString("n"),Base64.URL_SAFE|Base64.NO_WRAP);
            byte[] e=Base64.decode(key.getString("e"),Base64.URL_SAFE|Base64.NO_WRAP);
            java.security.PublicKey pub=KeyFactory.getInstance("RSA")
                .generatePublic(new RSAPublicKeySpec(new BigInteger(1,n),new BigInteger(1,e)));
            Signature verifier=Signature.getInstance("SHA256withRSA");
            verifier.initVerify(pub);
            verifier.update((parts[0]+"."+parts[1]).getBytes(StandardCharsets.US_ASCII));
            good=verifier.verify(Base64.decode(parts[2],Base64.URL_SAFE|Base64.NO_WRAP));
            if(good)break;
        }
        if(!good)throw new Exception("계정 인증 서명이 유효하지 않아.");
        return claims;
    }
    private static boolean audienceMatches(Object aud,String client) {
        if(aud instanceof String)return client.equals(aud);
        if(aud instanceof JSONArray){JSONArray arr=(JSONArray)aud;for(int i=0;i<arr.length();i++)if(client.equals(arr.optString(i)))return true;}
        return false;
    }
    private static boolean hasScope(String scopes,String wanted){
        for(String s:scopes.split("\\s+"))if(wanted.equals(s))return true;
        return false;
    }
    private String secret(int len){byte[] bytes=new byte[len];random.nextBytes(bytes);return urlB64(bytes);}
    private static String urlB64(byte[] bytes){return Base64.encodeToString(bytes,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    private static void param(StringBuilder url,String key,String value){
        if(url.charAt(url.length()-1)!='?')url.append('&');
        url.append(Uri.encode(key)).append('=').append(Uri.encode(value));
    }
    private static String form(String... kv){
        StringBuilder s=new StringBuilder();
        for(int i=0;i<kv.length;i+=2){if(i>0)s.append('&');s.append(Uri.encode(kv[i])).append('=').append(Uri.encode(kv[i+1]));}
        return s.toString();
    }
    private static JSONObject postForm(String endpoint,String data) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        try {
            c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(20000);
            c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            try(OutputStream out=c.getOutputStream()){out.write(data.getBytes(StandardCharsets.UTF_8));}
            if(c.getResponseCode()!=200)throw new Exception("OAuth 토큰 승인 실패 (HTTP "+c.getResponseCode()+")");
            return new JSONObject(read(c.getInputStream()));
        }finally{c.disconnect();}
    }
    private static JSONObject getJson(String url,String bearer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        try{
            c.setConnectTimeout(15000);c.setReadTimeout(20000);
            if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);
            if(c.getResponseCode()!=200)throw new Exception("보안 키 확인 실패");
            return new JSONObject(read(c.getInputStream()));
        }finally{c.disconnect();}
    }
    private static String read(InputStream in) throws Exception {
        try(InputStream stream=in;ByteArrayOutputStream buffer=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;
            while((n=stream.read(b))!=-1){buffer.write(b,0,n);if(buffer.size()>2_000_000)throw new Exception("서버 응답이 너무 길어.");}
            return buffer.toString("UTF-8");
        }
    }
    private Map<String,String> waitCallback(ServerSocket server) throws Exception {
        // A short-lived HTTP loopback server only, never exposed on LAN/WAN.
        try(Socket socket=server.accept()){
            socket.setSoTimeout(15000);
            BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.US_ASCII));
            String first=in.readLine();
            if(first==null||!first.startsWith("GET "))throw new Exception("OAuth callback 형식 오류");
            String target=first.split(" ")[1];
            Uri uri=Uri.parse(target);
            if(!REDIRECT_PATH.equals(uri.getPath()))throw new Exception("OAuth callback 경로 오류");
            // No token or code ever written to a log, response, file, or remote server.
            String page="<!doctype html><meta charset='utf-8'><title>EPLS</title><p>"+
                    "EPLS 인증이 반환되었습니다. 앱으로 돌아가 주세요.</p>";
            byte[] body=page.getBytes(StandardCharsets.UTF_8);
            String header="HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"+
                    "Cache-Control: no-store\r\nContent-Length: "+body.length+"\r\nConnection: close\r\n\r\n";
            socket.getOutputStream().write(header.getBytes(StandardCharsets.US_ASCII));
            socket.getOutputStream().write(body);socket.getOutputStream().flush();
            Map<String,String> result=new HashMap<>();
            for(String key:new String[]{"code","state","client_id","error","scope"}){
                String value=uri.getQueryParameter(key);if(value!=null)result.put(key,value);
            }
            return result;
        }
    }
    private static String shortError(Exception e) {
        String msg=e.getMessage();
        if(msg==null || msg.isEmpty())return "인증/통신 오류 ("+e.getClass().getSimpleName()+")";
        return msg.length()>160?msg.substring(0,160):msg;
    }
}
