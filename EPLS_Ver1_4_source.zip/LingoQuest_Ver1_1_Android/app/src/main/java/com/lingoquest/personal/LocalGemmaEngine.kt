package com.lingoquest.personal

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File
import java.util.concurrent.Executors

/**
 * Private, offline Gemma 4 E2B inference. This class contains no API endpoint, OAuth,
 * account/session access, telemetry, or metered cloud inference.
 * One background thread owns all LiteRT-LM operations (including shutdown).
 */
class LocalGemmaEngine {
    interface Callback {
        fun onReady()
        fun onReply(englishInput: String, englishReply: String)
        fun onTranslation(korean: String)
        fun onError(reason: String)
    }

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var ready = false
    @Volatile private var busy = false
    @Volatile private var closed = false
    private var engine: Engine? = null
    private var dialogue: Conversation? = null

    fun isReady(): Boolean = ready
    fun isBusy(): Boolean = busy

    fun load(modelPath: String, callback: Callback) {
        if (closed) return
        if (busy) { callback.onError("AI가 다른 작업을 처리 중이야."); return }
        busy = true
        worker.execute {
            try {
                val f = File(modelPath)
                require(f.isFile && f.length() > 2_300_000_000L) { "Gemma 4 모델 파일이 없거나 다운로드가 불완전해." }
                closeModel()
                // CPU first: broadest compatibility for Galaxy Tab S10 family.
                // A GPU toggle can be added after measured device tests.
                val candidate = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.CPU()))
                try {
                    candidate.initialize()
                } catch (e: Throwable) {
                    // An Engine whose initialize() fails must not be closed again.
                    throw e
                }
                engine = candidate
                dialogue = candidate.createConversation(
                    ConversationConfig(systemInstruction = Contents.of(
                        "You are Lumi, a kind and engaging English conversation partner for a Korean teen. " +
                        "Always reply in natural English, 1-3 short sentences. " +
                        "Keep the conversation going with one relevant question. " +
                        "Be safe, respectful, encouraging. Do not fabricate details about the student. " +
                        "If their English has a significant error, gently model the correct form without lecturing. " +
                        "Never disclose private account information. " +
                        "Do not include Korean translations unless explicitly requested in a separate task."
                    ), maxOutputToken = 256)
                )
                ready = true
                if (!closed) callback.onReady()
            } catch (e: Throwable) {
                ready = false
                if (!closed) callback.onError("모델 실행 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    fun chat(original: String, isKorean: Boolean, callback: Callback) {
        if (!ready || closed) { callback.onError("먼저 무료 Gemma 4 모델을 로드해 줘."); return }
        if (busy) { callback.onError("AI가 답변 중이야. 잠시 후 다시 말해 줘."); return }
        busy = true
        worker.execute {
            try {
                val e = requireNotNull(engine)
                val d = requireNotNull(dialogue)
                val englishInput = if (isKorean) oneShot(
                    e,
                    "You are a Korean-to-English translator for a teenager. Translate into natural, accurate conversational English. Return only the translation. Do not answer the question.",
                    original
                ) else original
                val reply = d.sendMessage(englishInput).toString().trim()
                require(reply.isNotEmpty()) { "AI가 빈 답변을 보냈어." }
                if (!closed) callback.onReply(englishInput, reply)
            } catch (e: Throwable) {
                if (!closed) callback.onError("AI 답변 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    /** Translation is requested only when user taps the Korean meaning button. */
    fun translate(english: String, callback: Callback) {
        if (!ready || closed) { callback.onError("AI 모델이 로드되지 않았어."); return }
        if (busy) { callback.onError("AI 작업이 끝난 뒤 해석해 줘."); return }
        busy = true
        worker.execute {
            try {
                val result = oneShot(
                    requireNotNull(engine),
                    "Translate the following English conversation reply to clear, natural Korean for a teenage English learner. Translate only; no notes, no extra English.",
                    english
                )
                if (!closed) callback.onTranslation(result)
            } catch (e: Throwable) {
                if (!closed) callback.onError("번역 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    fun reset(callback: Callback) {
        if (!ready || closed) return
        if (busy) { callback.onError("대화가 진행 중이야."); return }
        busy = true
        worker.execute {
            try {
                dialogue?.close()
                dialogue = requireNotNull(engine).createConversation(
                    ConversationConfig(systemInstruction = Contents.of(
                        "You are Lumi, a friendly English conversational tutor for a Korean teenager. " +
                        "Reply only in English, 1-3 short sentences; keep a natural conversation going with one question. " +
                        "Gently model corrections when appropriate. Never claim to know private facts."
                    ), maxOutputToken = 256)
                )
                if (!closed) callback.onReady()
            } catch (e: Throwable) {
                if (!closed) callback.onError("대화 초기화 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    private fun oneShot(e: Engine, instruction: String, input: String): String {
        e.createConversation(ConversationConfig(systemInstruction = Contents.of(instruction))).use { c ->
            return c.sendMessage(input).toString().trim().also {
                require(it.isNotEmpty()) { "모델의 결과가 비어 있어." }
            }
        }
    }

    private fun closeModel() {
        ready = false
        // Each resource closed at most once on the owner thread.
        val oldConversation = dialogue; dialogue = null
        val oldEngine = engine; engine = null
        try { oldConversation?.close() } catch (_: Throwable) {}
        try { oldEngine?.close() } catch (_: Throwable) {}
    }

    fun shutdown() {
        closed = true
        worker.execute { closeModel() }
        worker.shutdown()
    }

    private fun safe(e: Throwable): String =
        (e.message ?: e.javaClass.simpleName).take(240)
}
