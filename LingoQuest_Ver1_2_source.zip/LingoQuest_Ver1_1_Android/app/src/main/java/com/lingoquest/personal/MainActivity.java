package com.lingoquest.personal;

import android.Manifest;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import android.speech.tts.Voice;

/**
 * Lingo Quest Ver1.1 — no-cost Android native camera + microphone + TTS test app.
 * STT is on-device-only, if an Android on-device recognition service is installed.
 * Conversation replies are RULE-BASED DEMONSTRATIONS, not generative AI.
 * Face images and microphone recordings are never saved by this application.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(15, 21, 40);
    private static final int PANEL = Color.rgb(31, 41, 72);
    private static final int TEXT = Color.rgb(245, 248, 255);
    private static final int MUTED = Color.rgb(181, 197, 225);
    private static final int AQUA = Color.rgb(147, 238, 220);
    private static final int PURPLE = Color.rgb(169, 159, 242);

    private FrameLayout cameraBox;
    private PreviewView previewView;
    private TextView cameraPlaceholder;
    private TextView cameraToggle;
    private TextView status;
    private TextView ttsStatus;
    private TextView turnCounter;
    private LinearLayout transcriptList;
    private ScrollView transcriptScroll;
    private EditText input;
    private TeacherAvatarView avatar;
    private TextView audioToggle;
    private TextView speedToggle;
    private TextView languageToggle;
    private boolean cameraEnabled = false;
    private boolean autoSpeak = true;
    private boolean speakReady = false;
    private boolean isListening = false;
    private boolean koreanInput = false;
    private boolean ttsReady = false;
    private boolean speakTestAfterInit = false;
    private float speed = 1.0f;
    private int turns = 0;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private ProcessCameraProvider cameraProvider;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ActivityResultLauncher<String> cameraPermission;
    private ActivityResultLauncher<String> micPermission;

    private int dp(float value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private GradientDrawable bg(int fill, int radiusDp) {
        GradientDrawable b = new GradientDrawable(); b.setColor(fill);
        b.setCornerRadius(dp(radiusDp)); b.setStroke(dp(1), Color.rgb(60, 75, 113));
        return b;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(size);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)); }
    private LinearLayout.LayoutParams weighted(float weight) {return new LinearLayout.LayoutParams(0, -2, weight);}
    private TextView button(String label, int color) {
        TextView v = text(label, 13, TEXT, true); v.setGravity(Gravity.CENTER);
        v.setBackground(bg(color,14)); pad(v,12,10,12,10); v.setClickable(true); v.setFocusable(true);
        return v;
    }
    private void mark(String s) { status.setText(s); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        cameraPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) enableCamera(); else mark("카메라 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        micPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) beginRecognition(); else mark("마이크 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        turns = getPreferences(MODE_PRIVATE).getInt("turns",0);
        setupScreen(); setupTts();
        addBubble(false, "Hi! I'm Lumi. Let's practice English together!", "안녕! 나는 루미야. 함께 영어 연습하자!");
        boolean stt = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        mark(stt ? "준비 완료 · 무료 기기 내 음성 인식을 사용할 수 있어." : "기기 내 음성 인식 서비스 확인 필요 · 텍스트 연습은 가능해.");
    }

    private void setupScreen() {
        LinearLayout screen = vertical(); screen.setBackgroundColor(BG);
        setContentView(screen);
        LinearLayout heading = horizontal(); pad(heading,18,15,18,10);
        TextView logo = text("✦  LINGO QUEST",22, TEXT, true); heading.addView(logo, weighted(1));
        TextView chip = text("Ver1.1 • PRIVATE",10,AQUA,true); pad(chip,8,5,8,5);
        chip.setBackground(bg(PANEL,14)); heading.addView(chip); screen.addView(heading);
        ScrollView content = new ScrollView(this); content.setFillViewport(false);
        screen.addView(content, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body = vertical(); pad(body,14,4,14,15); content.addView(body);
        TextView subtitle = text("내 얼굴을 보며 AI 영어 선생님과 연습하는 공간",13,MUTED,false);
        body.addView(subtitle,lp(-1,-2));

        // Side-by-side teacher and selfie preview (native CameraX, not WebView).
        LinearLayout scenes = horizontal(); scenes.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams scenesMargin = lp(-1,-2); scenesMargin.topMargin=dp(13); body.addView(scenes,scenesMargin);
        LinearLayout teacherCard=vertical(); teacherCard.setBackground(bg(PANEL,20)); pad(teacherCard,8,8,8,9);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0,-2,1); half.rightMargin=dp(6);
        scenes.addView(teacherCard,half);
        TextView tLabel=text("✨ AI 선생님 · 루미",13,TEXT,true);tLabel.setGravity(Gravity.CENTER);teacherCard.addView(tLabel);
        avatar=new TeacherAvatarView(this);
        teacherCard.addView(avatar,lp(-1,186));
        TextView tInfo=text("영어로 말해 줄게!",11,AQUA,true);tInfo.setGravity(Gravity.CENTER);teacherCard.addView(tInfo);
        
        LinearLayout selfieCard=vertical(); selfieCard.setBackground(bg(PANEL,20));pad(selfieCard,8,8,8,9);
        LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,-2,1);half2.leftMargin=dp(6);
        scenes.addView(selfieCard,half2);
        TextView cLabel=text("📷 내 얼굴",13,TEXT,true);cLabel.setGravity(Gravity.CENTER);selfieCard.addView(cLabel);
        cameraBox=new FrameLayout(this); cameraBox.setBackground(bg(Color.rgb(20,29,53),15));
        previewView=new PreviewView(this);previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraBox.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        cameraPlaceholder=text("◉\n전면 카메라 꺼짐\n영상은 저장하지 않아",12,MUTED,true);
        cameraPlaceholder.setGravity(Gravity.CENTER);cameraPlaceholder.setBackground(bg(Color.rgb(20,29,53),15));
        cameraBox.addView(cameraPlaceholder,new FrameLayout.LayoutParams(-1,-1));
        selfieCard.addView(cameraBox,lp(-1,186));
        cameraToggle=button("카메라 켜기",Color.rgb(68,80,121));
        LinearLayout.LayoutParams toggleLp=lp(-1,38);toggleLp.topMargin=dp(6);
        selfieCard.addView(cameraToggle,toggleLp);
        cameraToggle.setOnClickListener(v->{ if(cameraEnabled)disableCamera(); else requestCamera(); });

        LinearLayout notice=vertical();notice.setBackground(bg(Color.rgb(26,37,63),15));pad(notice,12,11,12,11);
        LinearLayout.LayoutParams noticeLp=lp(-1,-2);noticeLp.topMargin=dp(14);body.addView(notice,noticeLp);
        status=text("시스템 초기화 중",12,AQUA,true);notice.addView(status);
        ttsStatus=text("🔊 영어 음성 엔진 확인 중...",11,MUTED,false);notice.addView(ttsStatus);
        TextView privacy=text("카메라 화면만 표시 · 영상/음성 파일 저장 없음 · 앱 인터넷 권한 없음",11,MUTED,false);
        LinearLayout.LayoutParams pLp=lp(-1,-2);pLp.topMargin=dp(4);notice.addView(privacy,pLp);

        LinearLayout tools=horizontal();LinearLayout.LayoutParams toolsLp=lp(-1,-2);toolsLp.topMargin=dp(13);body.addView(tools,toolsLp);
        languageToggle=button("🎤 영어로 말하기",Color.rgb(53,71,111));
        LinearLayout.LayoutParams tool1=new LinearLayout.LayoutParams(0,dp(46),1);tool1.rightMargin=dp(6);tools.addView(languageToggle,tool1);
        languageToggle.setOnClickListener(v->{ koreanInput=!koreanInput;
            languageToggle.setText(koreanInput?"🎤 한국어로 말하기":"🎤 영어로 말하기");
            mark(koreanInput?"마이크 언어: 한국어 · 한국어→영어 자동 번역은 미구현":"마이크 언어: 영어");
        });
        TextView speakBtn=button("● 마이크 시작",Color.rgb(108,77,143));
        LinearLayout.LayoutParams tool2=new LinearLayout.LayoutParams(0,dp(46),1);tool2.leftMargin=dp(6);tools.addView(speakBtn,tool2);
        speakBtn.setOnClickListener(v->{ if(isListening){ stopRecognition();mark("듣기를 중지했어."); } else requestMicrophone(); });
        
        LinearLayout settings=horizontal(); LinearLayout.LayoutParams sp=lp(-1,-2);sp.topMargin=dp(9);body.addView(settings,sp);
        audioToggle=button("🔊 자동 읽기 켜짐",Color.rgb(48,63,97));
        LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(0,dp(39),1);sb.rightMargin=dp(5);settings.addView(audioToggle,sb);
        audioToggle.setOnClickListener(v->{autoSpeak=!autoSpeak;audioToggle.setText(autoSpeak?"🔊 자동 읽기 켜짐":"🔈 자동 읽기 꺼짐");});
        speedToggle=button("속도: 보통",Color.rgb(48,63,97));
        LinearLayout.LayoutParams sb2=new LinearLayout.LayoutParams(0,dp(39),1);sb2.leftMargin=dp(5);settings.addView(speedToggle,sb2);
        speedToggle.setOnClickListener(v->{speed=(speed==1.0f)?0.8f:1.0f;
            speedToggle.setText(speed<1?"속도: 느리게":"속도: 보통");});
        TextView soundTest=button("🔊 영어 음성 테스트 / 엔진 재확인",Color.rgb(50,104,114));
        LinearLayout.LayoutParams stp=lp(-1,42);stp.topMargin=dp(8);body.addView(soundTest,stp);
        soundTest.setOnClickListener(v->{
            if(ttsReady) speak("Hello! I am Lumi. Can you hear my voice?");
            else setupTts(true);
        });
        
        LinearLayout chatHead=horizontal();LinearLayout.LayoutParams cp=lp(-1,-2);cp.topMargin=dp(18);body.addView(chatHead,cp);
        TextView chatLabel=text("💬 영어 대화",18,TEXT,true);chatHead.addView(chatLabel,weighted(1));
        turnCounter=text("연습 "+turns+"회",12,AQUA,true);chatHead.addView(turnCounter);
        transcriptScroll=new ScrollView(this);transcriptScroll.setFillViewport(true);
        LinearLayout.LayoutParams scrollLp=lp(-1,260);scrollLp.topMargin=dp(9);body.addView(transcriptScroll,scrollLp);
        transcriptList=vertical();pad(transcriptList,10,10,10,10);
        transcriptList.setBackground(bg(Color.rgb(22,30,53),18));transcriptScroll.addView(transcriptList);
        
        TextView demoLabel=text("Ver1.1은 규칙 응답 연습판 · 자유 대화 AI는 아직 연결되지 않았어.",11,MUTED,false);
        LinearLayout.LayoutParams dl=lp(-1,-2);dl.topMargin=dp(9);body.addView(demoLabel,dl);
        
        LinearLayout composer=horizontal();pad(composer,12,10,12,13);
        composer.setBackgroundColor(Color.rgb(20,28,49));screen.addView(composer);
        input=new EditText(this);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setTextSize(14);
        input.setSingleLine(false);input.setMaxLines(2);input.setHint("영어 또는 한국어로 입력...");
        input.setBackground(bg(PANEL,14));pad(input,12,9,12,9);
        LinearLayout.LayoutParams inputLp=new LinearLayout.LayoutParams(0,dp(54),1);inputLp.rightMargin=dp(8);
        composer.addView(input,inputLp);
        TextView send=button("보내기 ➜",Color.rgb(40,130,119));composer.addView(send,lp(90,54));
        send.setOnClickListener(v->{String s=input.getText().toString().trim();if(!s.isEmpty()){input.setText("");handleUser(s);} });
    }

    private void addBubble(boolean me,String english,String korean) {
        LinearLayout wrap=vertical();
        LinearLayout.LayoutParams wp=lp(-1,-2);wp.bottomMargin=dp(9);
        wrap.setBackground(bg(me?Color.rgb(51,51,94):PANEL,13));pad(wrap,12,10,12,10);
        TextView from=text(me?"나":"루미 선생님",11,me?PURPLE:AQUA,true);wrap.addView(from);
        TextView main=text(english,16,TEXT,false);LinearLayout.LayoutParams mp=lp(-1,-2);mp.topMargin=dp(3);wrap.addView(main,mp);
        if(korean!=null&&!korean.isEmpty()) {TextView trans=text(korean,12,MUTED,false);wrap.addView(trans);}
        transcriptList.addView(wrap,wp);
        transcriptScroll.post(()->transcriptScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void handleUser(String message) {
        boolean korean=message.matches(".*[가-힣].*");
        addBubble(true,message,korean?"한국어 인식/입력 · 번역 기능 미구현":"원문 텍스트");
        turns++;getPreferences(MODE_PRIVATE).edit().putInt("turns",turns).apply();turnCounter.setText("연습 "+turns+"회");
        String reply = demoReply(message);
        addBubble(false,reply,"규칙 기반 예시 답변 · 생성형 AI 아님");
        mark("영어 문장 생성 완료 · 음성 출력 확인 중");
        if(autoSpeak) speak(reply);
        else mark("답변 표시 완료 · 자동 읽기가 꺼져 있어. 다시 켜거나 음성 테스트를 눌러 줘.");
    }
    private String demoReply(String input) {
        String s=input.toLowerCase(Locale.ROOT);
        if(s.contains("hello")||s.contains("hi ")||s.contains("안녕"))return "Hello! It's nice to see you. How are you today?";
        if(s.contains("name")||s.contains("이름"))return "My name is Lumi. What is your name?";
        if(s.contains("thank")||s.contains("고마"))return "You're welcome! What would you like to practice next?";
        if(s.contains("food")||s.contains("먹")||s.contains("음식"))return "I love pizza! What kind of food do you like?";
        if(s.contains("school")||s.contains("학교"))return "That sounds interesting! What did you learn at school?";
        if(s.contains("weather")||s.contains("날씨"))return "Let's talk about the weather. Is it sunny where you are?";
        if(s.contains("yesterday")||s.contains("어제"))return "That's interesting! What happened after that?";
        if(s.contains("english")||s.contains("영어"))return "Great! We can practice English together. What topic do you like?";
        if(s.contains("?"))return "That's a good question! What do you think about it?";
        return "Thank you for sharing! Can you tell me a little more?";
    }

    private void updateTtsStatus(String message) {
        runOnUiThread(() -> { if (ttsStatus != null) ttsStatus.setText(message); });
    }
    private void setupTts() { setupTts(false); }
    private void setupTts(boolean testAfterInit) {
        // Allow changing the system TTS engine or downloading English voice data
        // without reinstalling the application.
        speakTestAfterInit = testAfterInit;
        ttsReady = false;
        updateTtsStatus("🔊 영어 음성 엔진 확인 중...");
        if(tts != null) {
            try { tts.stop(); tts.shutdown(); } catch(Exception ignored) {}
            tts = null;
        }
        tts = new TextToSpeech(this, result -> {
            if(result != TextToSpeech.SUCCESS || tts == null) {
                updateTtsStatus("❌ TTS 초기화 실패 · 설정 > 일반 > 글자 읽어주기에서 엔진을 확인해 줘.");
                return;
            }
            int lang = tts.setLanguage(Locale.US);
            if(lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                updateTtsStatus("❌ 영어 음성 데이터가 없어. 글자 읽어주기 > 음성 데이터 설치 > 영어(미국)");
                return;
            }
            // Avoid rejecting the engine simply because getVoices() is empty.
            // Prefer an offline American English voice, then any offline English
            // voice. If the system default is already offline, keep it.
            Voice best = null;
            Set<Voice> voices = tts.getVoices();
            if(voices != null) {
                for(Voice v : voices) {
                    if(v == null || v.isNetworkConnectionRequired() || v.getLocale() == null) continue;
                    if(!"en".equals(v.getLocale().getLanguage())) continue;
                    if(best == null || ("US".equals(v.getLocale().getCountry()) &&
                            !"US".equals(best.getLocale().getCountry()))) best = v;
                }
            }
            String voiceInfo = "기본 영어 음성";
            if(best != null) {
                if(tts.setVoice(best) == TextToSpeech.SUCCESS) voiceInfo = "오프라인 영어 음성";
            }
            Voice selected = tts.getVoice();
            if(selected != null && selected.isNetworkConnectionRequired()) {
                updateTtsStatus("❌ 현재 영어 목소리는 인터넷이 필요해. 무료 오프라인 영어 음성 데이터를 설치해 줘.");
                return;
            }
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(true); updateTtsStatus("🔊 영어 음성 재생 중..."); });
                }
                @Override public void onDone(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(false); updateTtsStatus("✅ 영어 음성 재생 완료"); });
                }
                @Override public void onError(String id) { showTtsError("엔진 출력 오류"); }
                @Override public void onError(String id, int code) { showTtsError("엔진 오류 코드 " + code); }
                private void showTtsError(String detail) {
                    runOnUiThread(() -> {
                        avatar.setSpeaking(false);
                        updateTtsStatus("❌ 영어 음성 실패: " + detail + " · 영어 데이터/미디어 음량을 확인해 줘.");
                    });
                }
            });
            ttsReady = true;
            AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if(am != null && am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
                updateTtsStatus("⚠️ 미디어 음량이 0이야. 볼륨 버튼으로 올려 줘.");
            } else {
                updateTtsStatus("✅ " + voiceInfo + " 준비 완료 · 아래 '영어 음성 테스트'를 눌러 봐.");
            }
            if(speakTestAfterInit) {
                speakTestAfterInit = false;
                runOnUiThread(() -> speak("Hello! I am Lumi. Can you hear my voice?"));
            }
        });
    }
    private void speak(String sentence) {
        if(!ttsReady || tts == null) {
            updateTtsStatus("❌ TTS가 준비되지 않았어. 영어 음성 테스트/엔진 재확인을 눌러 줘.");
            return;
        }
        tts.setSpeechRate(speed);
        int result = tts.speak(sentence, TextToSpeech.QUEUE_FLUSH, null,
                "lumi_"+System.currentTimeMillis());
        if(result == TextToSpeech.ERROR) {
            updateTtsStatus("❌ TTS 음성 요청 실패 · 글자 읽어주기 설정에서 영어(미국)를 확인해 줘.");
        }
    }
    private void requestCamera(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)enableCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }
    private void enableCamera() {
        cameraEnabled=true;cameraToggle.setText("카메라 끄기");cameraPlaceholder.setVisibility(View.GONE);
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(!cameraEnabled)return;
            try{
                cameraProvider=future.get();cameraProvider.unbindAll();
                Preview preview=new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview);
                mark("내 얼굴 표시 중 · 영상 저장 없음");
            }catch(Exception e){cameraEnabled=false;cameraPlaceholder.setVisibility(View.VISIBLE);
                cameraToggle.setText("카메라 켜기");mark("전면 카메라 시작 실패: "+e.getClass().getSimpleName());}
        },ContextCompat.getMainExecutor(this));
    }
    private void disableCamera(){cameraEnabled=false;if(cameraProvider!=null)cameraProvider.unbindAll();
        cameraPlaceholder.setVisibility(View.VISIBLE);cameraToggle.setText("카메라 켜기");mark("카메라 꺼짐 · 영상 저장 없음");}

    private void requestMicrophone(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)beginRecognition();
        else micPermission.launch(Manifest.permission.RECORD_AUDIO);
    }
    private void beginRecognition(){
        if(Build.VERSION.SDK_INT<31||!SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
            mark("오프라인 음성 인식이 설치되지 않았어. 기기 음성 서비스/언어팩을 확인해 줘.");return;
        }
        stopRecognition();
        try{
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle p){mark("듣고 있어… 문장을 말해 줘.");}
                @Override public void onBeginningOfSpeech(){mark("음성 인식 중…");}
                @Override public void onRmsChanged(float r){}
                @Override public void onBufferReceived(byte[] b){}
                @Override public void onEndOfSpeech(){mark("음성을 텍스트로 변환 중…");}
                @Override public void onError(int code){
                    isListening=false;String suffix=code==SpeechRecognizer.ERROR_NO_MATCH?"음성을 알아듣지 못했어.":
                        code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"말소리가 들리지 않았어.":
                        code==SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE?"해당 언어 모델이 설치되지 않았어.":
                        "인식 오류 코드 "+code;
                    mark(suffix+" 다시 시도하거나 텍스트를 입력해 줘.");
                    disposeRecognizer();
                }
                @Override public void onResults(Bundle b){
                    isListening=false;ArrayList<String> result=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(result!=null&&!result.isEmpty())handleUser(result.get(0));
                    else mark("음성 인식 결과가 없어. 다시 말해 줘.");
                    disposeRecognizer();
                }
                @Override public void onPartialResults(Bundle b){}
                @Override public void onEvent(int type, Bundle p){}
            });
            Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,koreanInput?"ko-KR":"en-US");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);
            isListening=true;recognizer.startListening(intent);
        }catch(Exception e){isListening=false;disposeRecognizer();mark("마이크 시작 실패: "+e.getMessage());}
    }
    private void stopRecognition(){isListening=false;if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}}
    private void disposeRecognizer(){if(recognizer!=null){try{recognizer.destroy();}catch(Exception ignored){}recognizer=null;}}
    @Override protected void onResume(){super.onResume();if(cameraEnabled&&cameraProvider!=null)enableCamera();}
    @Override protected void onPause(){super.onPause();if(cameraProvider!=null)cameraProvider.unbindAll();stopRecognition();if(tts!=null)tts.stop();avatar.setSpeaking(false);}
    @Override protected void onDestroy(){disableCamera();stopRecognition();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
