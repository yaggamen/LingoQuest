package com.lingoquest.personal;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** A tiny original pixel-character, drawn locally. No image assets or network. */
public final class TeacherAvatarView extends View {
    private final Paint p = new Paint();
    private volatile boolean speaking;
    private int frame;

    public TeacherAvatarView(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setSpeaking(boolean v) { speaking = v; invalidate(); }
    private void rect(Canvas c, int x, int y, int w, int h, String color) {
        p.setColor(Color.parseColor(color)); c.drawRect(x,y,x+w,y+h,p);
    }
    @Override protected void onDraw(Canvas original) {
        super.onDraw(original);
        int save = original.save();
        float scale = Math.min(getWidth()/140f, getHeight()/150f);
        original.translate((getWidth()-140*scale)/2, (getHeight()-150*scale)/2);
        original.scale(scale,scale);
        Canvas c = original;
        rect(c,29,138,82,5,"#172340");
        // Boots and wizard coat
        rect(c,44,116,19,25,"#4F3B80"); rect(c,77,116,19,25,"#4F3B80");
        rect(c,37,91,66,42,"#765CC1");rect(c,45,92,50,42,"#A38EE5");
        rect(c,61,107,19,26,"#81E4D1");
        rect(c,26,100,18,10,"#FFD5AF");rect(c,96,100,18,10,"#FFD5AF");
        rect(c,26,94,14,11,"#7259B6");rect(c,100,94,14,11,"#7259B6");
        // Hair and head
        rect(c,36,26,68,71,"#4A386E");rect(c,40,37,60,52,"#FFD8B8");
        rect(c,36,41,10,50,"#66508F");rect(c,94,41,10,50,"#66508F");
        rect(c,40,25,60,18,"#66508F");rect(c,46,18,47,14,"#4A386E");
        rect(c,53,15,32,9,"#8CEEDC");
        // Eyes, cheeks, and animated mouth
        rect(c,51,58,8,6,"#272644");rect(c,80,58,8,6,"#272644");
        rect(c,53,59,2,2,"#FFFFFF");rect(c,82,59,2,2,"#FFFFFF");
        rect(c,46,70,11,4,"#F1ACAB");rect(c,82,70,11,4,"#F1ACAB");
        rect(c,66,75,8,(speaking && frame%2==0)?7:3,"#B86283");
        // Book held by teacher
        rect(c,97,108,22,21,"#E3D3A9");rect(c,99,110,18,16,"#FFF2CC");
        rect(c,104,115,9,2,"#A18AC4");rect(c,104,120,9,2,"#A18AC4");
        original.restoreToCount(save);
        if (speaking) { frame++; postInvalidateDelayed(160); }
    }
}
