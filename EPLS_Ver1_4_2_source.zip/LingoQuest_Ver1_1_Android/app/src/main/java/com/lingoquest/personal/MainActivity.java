package com.lingoquest.personal;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.ModelDownloadListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import android.speech.tts.Voice;

/**
 * Easy Peasy Lemon Speak Ver1.4.2 — local Gemma 4 voice tutor.
 * No GPT account, billing, paid API, cloud inference, or chat data upload.
 * Internet permission is only for optional user-initiated model download.
 * Camera is preview-only; voice recognition uses Android on-device service.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(15, 21, 40);
    private static final int PANEL = Color.rgb(31, 41, 72);
    private static final int TEXT = Color.rgb(245, 248, 255);
    private static final int MUTED = Color.rgb(181, 197, 225);
    private static final int AQUA = Color.rgb(147, 238, 220);
    private static final int PURPLE = Color.rgb(169, 159, 242);

    private FrameLayout cameraBox;
    private PreviewView previewView;
    private TextView cameraPlaceholder;
    private TextView cameraToggle;
    private TextView status;
    private TextView ttsStatus;
    private TextView turnCounter;
    private LinearLayout transcriptList;
    private ScrollView transcriptScroll;
    private EditText input;
    private TeacherAvatarView avatar;
    private TextView audioToggle;
    private TextView speedToggle;
    private TextView languageToggle;
    private boolean cameraEnabled = false;
    private boolean autoSpeak = true;
    private boolean speakReady = false;
    private boolean isListening = false;
    private boolean koreanInput = false;
    private boolean ttsReady = false;
    private boolean speakTestAfterInit = false;
    private float speed = 1.0f;
    private int turns = 0;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private ProcessCameraProvider cameraProvider;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ActivityResultLauncher<String> cameraPermission;
    private ActivityResultLauncher<String> micPermission;
    private LocalGemmaEngine gemma;
    private TextView modelButton;
    private TextView modelStatus;
    private TextView microphoneButton;
    private TextView modelMenuButton;
    private LinearLayout modelPanel;
    private LinearLayout scenePanel;
    private boolean waitingForMicResult = false;
    private String partialMicText = "";
    private String draftBeforeMic = "";
    private boolean manuallyFinishedMic = false;
    private boolean micResultHandled = false;
    private int micSession = 0;
    private SpeechRecognizer downloadRecognizer;
    private boolean autoFollow = true;
    private String queuedVoiceMessage = null;
    private boolean generating = false;
    private long downloadId = -1L;
    private Runnable progressPoll;
    private static final String MODEL_NAME = "gemma-4-E2B-it.litertlm";
    // Official public, Apache-2.0 LiteRT Community model (downloaded once, not bundled).
    private static final String MODEL_URL =
        "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm";
    private static final long MODEL_MIN = 2_300_000_000L;
    private static final long MODEL_MAX = 3_100_000_000L;

    private int dp(float value) { return Math.round(getResources().getDisplayMetrics().density * value); }
    private GradientDrawable bg(int fill, int radiusDp) {
        GradientDrawable b = new GradientDrawable(); b.setColor(fill);
        b.setCornerRadius(dp(radiusDp)); b.setStroke(dp(1), Color.rgb(60, 75, 113));
        return b;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(size);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)); }
    private LinearLayout.LayoutParams weighted(float weight) {return new LinearLayout.LayoutParams(0, -2, weight);}
    private TextView button(String label, int color) {
        TextView v = text(label, 13, TEXT, true); v.setGravity(Gravity.CENTER);
        v.setBackground(bg(color,14)); pad(v,12,10,12,10); v.setClickable(true); v.setFocusable(true);
        return v;
    }
    private void mark(String s) { if(status!=null) status.setText(s); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        cameraPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) enableCamera(); else mark("카메라 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        micPermission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            if (granted) beginRecognition(); else mark("마이크 권한이 거부됐어. 설정에서 허용할 수 있어.");
        });
        turns = getPreferences(MODE_PRIVATE).getInt("turns",0);
        gemma = new LocalGemmaEngine();
        setupScreen(); setupTts();
        boolean stt = Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        mark(stt ? "준비 완료 · 영어로 말을 걸어 줘." : "오프라인 음성 인식 언어팩/서비스를 확인해 줘.");
        // Automatically reopen a previously downloaded model on app startup.
        ui.post(() -> { if (validModel()) prepareModel(); else showModelPanel(); });
    }

    private void setupScreen() {
        // Stable vertical layout: the conversation itself takes the remaining screen
        // height. Input stays above system navigation/IME, not on top of translations.
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout screen = vertical(); screen.setBackgroundColor(BG);
        screen.setFitsSystemWindows(true);
        setContentView(screen);

        LinearLayout heading = horizontal(); pad(heading,12,8,12,6);
        TextView logo=text("✦ EPLS",19,TEXT,true);heading.addView(logo,weighted(1));
        TextView chip=text("1.4.2",11,AQUA,true);pad(chip,8,4,8,4);chip.setBackground(bg(PANEL,12));heading.addView(chip);
        modelMenuButton=button("⚙ AI / 화면",Color.rgb(44,62,98));
        LinearLayout.LayoutParams manage=lp(108,34);manage.leftMargin=dp(8);heading.addView(modelMenuButton,manage);
        screen.addView(heading);

        // Setup/diagnostics are hidden by default; a learner sees the conversation.
        modelPanel=vertical();modelPanel.setBackground(bg(PANEL,10));pad(modelPanel,9,8,9,8);
        LinearLayout.LayoutParams modelLp=lp(-1,-2);modelLp.leftMargin=dp(10);modelLp.rightMargin=dp(10);
        screen.addView(modelPanel,modelLp);modelPanel.setVisibility(View.GONE);
        modelMenuButton.setOnClickListener(v->{
            modelPanel.setVisibility(modelPanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);
        });
        modelStatus=text("Gemma 4 모델 준비 확인 중",12,MUTED,false);
        modelPanel.addView(modelStatus);
        modelButton=button("AI 모델 다운로드 / 시작",Color.rgb(47,98,116));
        LinearLayout.LayoutParams mdl=lp(-1,40);mdl.topMargin=dp(5);modelPanel.addView(modelButton,mdl);
        modelButton.setOnClickListener(v->prepareModel());
        TextView resetButton=button("새로운 대화",Color.rgb(51,67,103));
        LinearLayout.LayoutParams resetLp=lp(-1,36);resetLp.topMargin=dp(5);modelPanel.addView(resetButton,resetLp);
        resetButton.setOnClickListener(v->{
            if(generating) {mark("AI 답변이 끝난 뒤 새 대화를 시작할 수 있어.");return;}
            gemma.reset(new LocalGemmaEngine.Callback() {
                @Override public void onReady(){runOnUiThread(()->{mark("새로운 대화를 시작했어.");transcriptList.removeAllViews();queuedVoiceMessage=null;});}
                @Override public void onReply(String a,String b){}
                @Override public void onPartialReply(String a,String b){}
                @Override public void onTranslation(String a){}
                @Override public void onError(String why){runOnUiThread(()->mark(why));}
            });
        });
        TextView soundTest=button("영어 음성 점검",Color.rgb(51,67,103));
        LinearLayout.LayoutParams tst=lp(-1,36);tst.topMargin=dp(5);modelPanel.addView(soundTest,tst);
        soundTest.setOnClickListener(v->{if(ttsReady)speak("Hello! I am Lumi. Can you hear my voice?");else setupTts(true);});
        TextView ttsMini=text("영어 음성 확인 중",11,MUTED,false);
        ttsStatus=ttsMini;modelPanel.addView(ttsMini);
        TextView privacy=text("개인정보: 생성형 AI·음성 인식은 기기 내부 처리. 카메라/오디오 파일 저장 안 함.",10,MUTED,false);
        modelPanel.addView(privacy);

        // Keep the teacher and selfie preview, but allow learners to hide them.
        scenePanel=horizontal();scenePanel.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams scenesMargin=lp(-1,-2);
        scenesMargin.leftMargin=dp(10);scenesMargin.rightMargin=dp(10);
        screen.addView(scenePanel,scenesMargin);
        LinearLayout teacherCard=vertical();teacherCard.setBackground(bg(PANEL,12));pad(teacherCard,5,4,5,3);
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,-2,1);half.rightMargin=dp(4);scenePanel.addView(teacherCard,half);
        avatar=new TeacherAvatarView(this);teacherCard.addView(avatar,lp(-1,96));
        LinearLayout selfieCard=vertical();selfieCard.setBackground(bg(PANEL,12));pad(selfieCard,5,4,5,3);
        LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,-2,1);half2.leftMargin=dp(4);scenePanel.addView(selfieCard,half2);
        cameraBox=new FrameLayout(this);cameraBox.setBackground(bg(Color.rgb(20,29,53),10));
        previewView=new PreviewView(this);previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraBox.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        cameraPlaceholder=text("내 얼굴 · 카메라 꺼짐",11,MUTED,false);
        cameraPlaceholder.setGravity(Gravity.CENTER);cameraBox.addView(cameraPlaceholder,new FrameLayout.LayoutParams(-1,-1));
        selfieCard.addView(cameraBox,lp(-1,72));
        cameraToggle=button("카메라 켜기",Color.rgb(59,73,108));
        LinearLayout.LayoutParams cameraLp=lp(-1,25);cameraLp.topMargin=dp(2);selfieCard.addView(cameraToggle,cameraLp);
        cameraToggle.setOnClickListener(v->{if(cameraEnabled)disableCamera();else requestCamera();});
        TextView scenesToggle=button("캐릭터/카메라 접기",Color.rgb(39,54,83));
        LinearLayout.LayoutParams sceneToggleLp=lp(-1,27);sceneToggleLp.leftMargin=dp(10);sceneToggleLp.rightMargin=dp(10);
        screen.addView(scenesToggle,sceneToggleLp);
        scenesToggle.setOnClickListener(v->{boolean hide=scenePanel.getVisibility()==View.VISIBLE;
            scenePanel.setVisibility(hide?View.GONE:View.VISIBLE);
            scenesToggle.setText(hide?"캐릭터/카메라 펼치기":"캐릭터/카메라 접기");
        });

        // One compact, visible status line, without repeated technical explanations.
        status=text("준비 중",11,AQUA,true);status.setMaxLines(2);pad(status,12,5,12,4);
        screen.addView(status);

        LinearLayout tools=horizontal();pad(tools,10,0,10,0);
        screen.addView(tools);
        languageToggle=button("영어 입력",Color.rgb(53,71,111));
        LinearLayout.LayoutParams tool1=new LinearLayout.LayoutParams(0,dp(43),1);tool1.rightMargin=dp(4);tools.addView(languageToggle,tool1);
        languageToggle.setOnClickListener(v->{if(isListening||waitingForMicResult){mark("먼저 현재 음성 인식을 끝내 줘.");return;}
            koreanInput=!koreanInput;
            languageToggle.setText(koreanInput?"한국어 입력":"영어 입력");
            mark(koreanInput?"한국어로 말해 줘.":"영어로 말해 줘.");
        });
        microphoneButton=button("🎤 말하기",Color.rgb(108,77,143));
        LinearLayout.LayoutParams tool2=new LinearLayout.LayoutParams(0,dp(43),1);tool2.leftMargin=dp(4);tools.addView(microphoneButton,tool2);
        microphoneButton.setOnClickListener(v->{
            if(isListening){finishRecognition();}
            else if(waitingForMicResult){mark("음성 인식 결과를 기다리는 중이야.");}
            else requestMicrophone();
        });
        LinearLayout settings=horizontal();pad(settings,10,5,10,0);screen.addView(settings);
        audioToggle=button("🔊 자동 읽기 켜짐",Color.rgb(45,60,94));
        LinearLayout.LayoutParams sb=new LinearLayout.LayoutParams(0,dp(29),1);sb.rightMargin=dp(5);settings.addView(audioToggle,sb);
        audioToggle.setOnClickListener(v->{autoSpeak=!autoSpeak;audioToggle.setText(autoSpeak?"🔊 자동 읽기 켜짐":"🔈 자동 읽기 꺼짐");});
        speedToggle=button("음성 속도: 보통",Color.rgb(45,60,94));
        LinearLayout.LayoutParams sb2=new LinearLayout.LayoutParams(0,dp(29),1);sb2.leftMargin=dp(5);settings.addView(speedToggle,sb2);
        speedToggle.setOnClickListener(v->{speed=(speed==1.0f)?0.8f:1.0f;
            speedToggle.setText(speed<1?"음성 속도: 천천히":"음성 속도: 보통");});

        LinearLayout chatHead=horizontal();pad(chatHead,12,7,12,3);screen.addView(chatHead);
        TextView chatLabel=text("💬 영어 대화",16,TEXT,true);chatHead.addView(chatLabel,weighted(1));
        turnCounter=text("연습 "+turns+"회",11,AQUA,true);chatHead.addView(turnCounter);
        // No nested fixed-height scroll view: available screen height belongs to chat.
        transcriptScroll=new ScrollView(this);transcriptScroll.setFillViewport(true);
        transcriptScroll.setVerticalScrollBarEnabled(true);transcriptScroll.setSmoothScrollingEnabled(true);
        LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(-1,0,1);
        scrollLp.leftMargin=dp(9);scrollLp.rightMargin=dp(9);scrollLp.bottomMargin=dp(3);
        screen.addView(transcriptScroll,scrollLp);
        transcriptList=vertical();pad(transcriptList,7,7,7,45);
        transcriptList.setBackground(bg(Color.rgb(22,30,53),13));transcriptScroll.addView(transcriptList);
        transcriptScroll.setOnTouchListener((v,event)->{ if(event.getAction()==android.view.MotionEvent.ACTION_UP)
            autoFollow=isNearBottom();return false;});

        LinearLayout composer=horizontal();pad(composer,10,7,10,9);
        composer.setBackgroundColor(Color.rgb(20,28,49));screen.addView(composer);
        input=new EditText(this);input.setTextColor(TEXT);input.setHintTextColor(MUTED);input.setTextSize(14);
        input.setSingleLine(false);input.setMaxLines(3);input.setHint("영어 또는 한국어로 입력...");
        input.setBackground(bg(PANEL,12));pad(input,11,8,11,8);
        LinearLayout.LayoutParams inputLp=new LinearLayout.LayoutParams(0,dp(49),1);inputLp.rightMargin=dp(6);
        composer.addView(input,inputLp);
        TextView send=button("보내기",Color.rgb(40,130,119));composer.addView(send,lp(72,49));
        send.setOnClickListener(v->{String msg=input.getText().toString().trim();if(msg.isEmpty())return;
            if(!gemma.isReady()||generating||gemma.isBusy()){
                mark(!gemma.isReady()?"AI 모델을 먼저 시작해 줘. 입력한 문장은 보관돼.":"AI 답변을 기다려 줘. 입력한 문장은 보관돼.");return;
            }
            input.setText("");handleUser(msg);
        });
    }

    private void showModelPanel(){
        if(modelPanel!=null)modelPanel.setVisibility(View.VISIBLE);
    }
    private boolean isNearBottom(){
        if(transcriptScroll==null || transcriptScroll.getChildCount()==0)return true;
        View child=transcriptScroll.getChildAt(0);
        int remaining=child.getHeight()-(transcriptScroll.getScrollY()+transcriptScroll.getHeight());
        return remaining<dp(75);
    }
    private void followBottom(boolean force){
        if(!force&&!autoFollow)return;
        transcriptScroll.post(()->{
            transcriptScroll.scrollTo(0,Math.max(0,transcriptList.getHeight()-transcriptScroll.getHeight()));
        });
    }

    private void addBubble(boolean me,String english,String korean) {
        LinearLayout wrap=vertical();
        LinearLayout.LayoutParams wp=lp(-1,-2);wp.bottomMargin=dp(9);
        wrap.setBackground(bg(me?Color.rgb(51,51,94):PANEL,13));pad(wrap,12,10,12,10);
        TextView from=text(me?"나":"루미 선생님",11,me?PURPLE:AQUA,true);wrap.addView(from);
        TextView main=text(english,16,TEXT,false);LinearLayout.LayoutParams mp=lp(-1,-2);mp.topMargin=dp(3);wrap.addView(main,mp);
        if(korean!=null&&!korean.isEmpty()) {TextView trans=text(korean,12,MUTED,false);wrap.addView(trans);}
        transcriptList.addView(wrap,wp);
        followBottom(me || autoFollow);
    }

    private TextView addAiReply(String reply) {
        LinearLayout wrap=vertical();
        LinearLayout.LayoutParams wp=lp(-1,-2);wp.bottomMargin=dp(9);
        wrap.setBackground(bg(PANEL,13));pad(wrap,12,10,12,10);
        TextView name=text("루미 · Gemma 4 실제 생성 답변",11,AQUA,true);wrap.addView(name);
        TextView body=text(reply,16,TEXT,false);
        LinearLayout.LayoutParams bp=lp(-1,-2);bp.topMargin=dp(5);wrap.addView(body,bp);
        TextView translation=text("",13,MUTED,false);translation.setVisibility(View.GONE);
        TextView btn=button("🇰🇷 이 답변 한국어 해석",Color.rgb(47,72,102));
        LinearLayout.LayoutParams bt=lp(-1,37);bt.topMargin=dp(8);wrap.addView(btn,bt);
        wrap.addView(translation);
        btn.setOnClickListener(v->{
            if(gemma.isBusy()){mark("AI가 다른 작업을 처리 중이야.");return;}
            btn.setText("해석 중...");
            gemma.translate(body.getText().toString(),new LocalGemmaEngine.Callback(){
                @Override public void onReady(){}
                @Override public void onReply(String englishInput,String englishReply){}
                @Override public void onPartialReply(String en,String partial){}
                @Override public void onTranslation(String korean){runOnUiThread(()->{
                    translation.setText("해석: " + korean); translation.setVisibility(View.VISIBLE);
                    btn.setText("🇰🇷 한국어 해석 완료");
                    autoFollow=true;
                    transcriptScroll.postDelayed(()->followBottom(true),80);
                });}
                @Override public void onError(String why){runOnUiThread(()->{btn.setText("🇰🇷 다시 해석하기");mark(why);});}
            });
        });
        transcriptList.addView(wrap,wp);
        followBottom(true);
        return body;
    }

    /** Read finished sentences while the model continues generating later sentences. */
    private void playGeneratedSentences(String fullText, int[] spokenEnd, boolean[] spokenAny, boolean finalPart) {
        if (!autoSpeak || !ttsReady || tts == null) return;
        while (spokenEnd[0] < fullText.length()) {
            int boundary = -1;
            for (int i = spokenEnd[0]; i < fullText.length() - 1; i++) {
                char c = fullText.charAt(i);
                if (c != '.' && c != '!' && c != '?') continue;
                int j = i + 1;
                while (j < fullText.length() && (fullText.charAt(j) == '\"' || fullText.charAt(j) == '\'')) j++;
                if (j < fullText.length() && Character.isWhitespace(fullText.charAt(j))) {
                    boundary = j;
                    break;
                }
            }
            if (boundary < 0) {
                if (!finalPart) break;
                boundary = fullText.length();
            }
            String sentence = fullText.substring(spokenEnd[0], boundary).trim();
            spokenEnd[0] = boundary;
            if (sentence.isEmpty()) continue;
            tts.setSpeechRate(speed);
            int mode = spokenAny[0] ? TextToSpeech.QUEUE_ADD : TextToSpeech.QUEUE_FLUSH;
            int result = tts.speak(sentence, mode, null, "lumi_stream_" + System.nanoTime());
            if (result == TextToSpeech.SUCCESS) spokenAny[0] = true;
        }
    }

    private void handleUser(String message) {
        if(!gemma.isReady()) {
            mark("먼저 '무료 AI 모델 다운로드 / 시작'을 눌러 모델을 로드해 줘.");return;
        }
        if(generating || gemma.isBusy()) {mark("Gemma가 처리 중이야. 답변이 끝난 뒤 다시 말해 줘.");return;}
        // Stop an older spoken reply when the student starts a new turn.
        if(tts != null) tts.stop();
        final boolean korean=message.matches(".*[가-힣].*");
        addBubble(true,message,korean?"한국어 원문 · AI가 영어 표현으로 바꿔줄게":"입력한 영어 원문");
        generating = true;
        mark(korean?"Gemma가 한국어를 정확하게 영어로 옮기는 중...":"Gemma가 영어 답변을 생성하는 중...");
        final TextView[] streamingText = new TextView[1];
        final boolean[] englishShown = {false};
        final int[] spokenEnd = {0};
        final boolean[] spokenAny = {false};
        gemma.chat(message,korean,new LocalGemmaEngine.Callback(){
            @Override public void onReady(){}
            @Override public void onPartialReply(String englishInput,String textSoFar){runOnUiThread(()->{
                if(korean && !englishShown[0]) {
                    addBubble(true,englishInput,"내 한국어를 영어로 표현하면 이렇게 말할 수 있어.");
                    englishShown[0] = true;
                }
                if(streamingText[0] == null) streamingText[0] = addAiReply("");
                streamingText[0].setText(textSoFar);
                followBottom(false);
                mark("루미가 영어로 대답하고 있어... · " + gemma.backendName() + " 모드");
                playGeneratedSentences(textSoFar,spokenEnd,spokenAny,false);
            });}
            @Override public void onReply(String englishInput,String reply){runOnUiThread(()->{
                generating=false;
                if(korean && !englishShown[0]) addBubble(true,englishInput,"내 한국어를 영어로 표현하면 이렇게 말할 수 있어.");
                if(streamingText[0] == null) streamingText[0] = addAiReply(reply);
                else streamingText[0].setText(reply);
                followBottom(false);
                playGeneratedSentences(reply,spokenEnd,spokenAny,true);
                turns++;getPreferences(MODE_PRIVATE).edit().putInt("turns",turns).apply();
                turnCounter.setText("연습 "+turns+"회");
                mark("✅ 답변 완료 · " + gemma.backendName() + " 모드");
                sendQueuedVoiceIfAny();
            });}
            @Override public void onTranslation(String korean){}
            @Override public void onError(String why){runOnUiThread(()->{generating=false;mark(why);sendQueuedVoiceIfAny();});}
        });
    }

    private void sendQueuedVoiceIfAny(){
        if(queuedVoiceMessage==null)return;
        final String queued=queuedVoiceMessage;
        queuedVoiceMessage=null;
        if(input.getText().toString().trim().equals(queued))input.setText("");
        ui.postDelayed(()->{
            if(gemma.isReady()&&!gemma.isBusy()&&!generating)handleUser(queued);
            else{queuedVoiceMessage=queued;input.setText(queued);mark("다음 음성 질문을 입력창에 보관했어. 보내기를 눌러 줘.");}
        },120);
    }
    private File modelFile() {
        File folder=getExternalFilesDir(null);
        if(folder==null) throw new IllegalStateException("앱 저장 공간에 접근할 수 없어.");
        return new File(folder,MODEL_NAME);
    }
    private boolean validModel() {
        File f=modelFile();return f.isFile() && f.length()>=MODEL_MIN && f.length()<=MODEL_MAX;
    }
    private void prepareModel() {
        if (gemma.isReady()) {mark("이미 Gemma 4가 실행 중이야. 바로 말해 줘!");return;}
        if(gemma.isBusy()) {mark("모델이 로드되고 있어.");return;}
        if(downloadId!=-1L) {mark("다운로드 진행 중이야. 모델 상태를 확인해 줘.");return;}
        if(validModel()) {
            modelStatus.setText("모델 파일 확인 완료 · 실행 준비 중...");
            modelButton.setText("AI 시작 중...");
            gemma.load(modelFile().getAbsolutePath(),new LocalGemmaEngine.Callback(){
                @Override public void onReady(){runOnUiThread(()->{
                    modelStatus.setText("✅ Gemma 4 E2B 로컬 AI 준비 완료 · " + gemma.backendName() + " 사용");
                    modelButton.setText("✅ Gemma 4 실행 중");mark("AI 준비 완료 · 영어로 말을 걸어 줘.");
                });}
                @Override public void onReply(String en,String reply){}
                @Override public void onPartialReply(String en,String partial){}
                @Override public void onTranslation(String ko){}
                @Override public void onError(String why){runOnUiThread(()->{
                    modelStatus.setText("⚠️ " + why);modelButton.setText("무료 AI 모델 다시 시작");mark(why);
                });}
            });
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("무료 Gemma 4 E2B 다운로드")
            .setMessage("최초 한 번 약 2.6GB 파일을 Wi-Fi로 다운로드해. 이후 AI 대화는 갤럭시탭 안에서 처리돼. 별도 API 요금이 발생하지 않아. 앱 삭제 시 다운로드 파일도 지워질 수 있어.")
            .setNegativeButton("취소",(d,w)->{})
            .setPositiveButton("무료 다운로드",(d,w)->downloadModel())
            .show();
    }
    private void downloadModel() {
        try {
            File file=modelFile();
            StatFs stat=new StatFs(file.getParentFile().getAbsolutePath());
            if(stat.getAvailableBytes()<3_300_000_000L) {
                mark("저장 공간이 부족해. 최소 3.3GB 이상 확보해 줘.");return;
            }
            if(file.exists()&&!file.delete()) {mark("기존 미완료 파일 삭제 실패. 저장 공간을 확인해 줘.");return;}
            DownloadManager manager=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request req=new DownloadManager.Request(Uri.parse(MODEL_URL))
                .setTitle("EPLS 무료 Gemma 4 AI 모델")
                .setDescription("최초 1회 다운로드 · 약 2.6GB")
                .setMimeType("application/octet-stream")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(false)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(this,null,MODEL_NAME);
            downloadId=manager.enqueue(req);
            modelButton.setText("모델 다운로드 중...");
            modelStatus.setText("Wi-Fi 연결 확인 · 약 2.6GB 다운로드 시작");
            progressPoll=this::pollDownload;
            ui.postDelayed(progressPoll,1300);
        }catch(Exception e) {downloadId=-1L;mark("모델 다운로드 시작 실패: "+e.getMessage());}
    }
    private void pollDownload() {
        if(downloadId<0)return;
        DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Query query=new DownloadManager.Query().setFilterById(downloadId);
        try(Cursor c=dm.query(query)) {
            if(c==null||!c.moveToFirst()) {mark("모델 다운로드 상태를 확인할 수 없어.");downloadId=-1L;return;}
            int state=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            if(state==DownloadManager.STATUS_SUCCESSFUL) {
                downloadId=-1L;
                if(validModel()) {
                    modelStatus.setText("다운로드 완료 · Gemma 4 초기화 중...");
                    prepareModel();
                }else {modelStatus.setText("모델 파일 크기가 예상과 달라. 다시 내려받아 줘.");modelButton.setText("다시 다운로드");}
                return;
            }
            if(state==DownloadManager.STATUS_FAILED) {
                int reason=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON));
                downloadId=-1L;modelButton.setText("모델 다운로드 재시도");
                modelStatus.setText("다운로드 실패 코드 " + reason + " · Wi-Fi 및 저장 공간을 확인해 줘.");return;
            }
            long sofar=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long total=c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            String pct=total>0?(100*sofar/total)+"%":"진행 중";
            modelStatus.setText("모델 다운로드 " + pct + " · " + (sofar/1_000_000)+"MB / "+(total>0?(total/1_000_000)+"MB":"약 2,600MB") + " · Wi-Fi 필요");
        }catch(Exception e){downloadId=-1L;modelStatus.setText("다운로드 상태 오류: "+e.getMessage());return;}
        progressPoll=this::pollDownload;
        ui.postDelayed(progressPoll,1500);
    }

    private void updateTtsStatus(String message) {
        runOnUiThread(() -> { if (ttsStatus != null) ttsStatus.setText(message); });
    }
    private void setupTts() { setupTts(false); }
    private void setupTts(boolean testAfterInit) {
        // Allow changing the system TTS engine or downloading English voice data
        // without reinstalling the application.
        speakTestAfterInit = testAfterInit;
        ttsReady = false;
        updateTtsStatus("🔊 영어 음성 엔진 확인 중...");
        if(tts != null) {
            try { tts.stop(); tts.shutdown(); } catch(Exception ignored) {}
            tts = null;
        }
        tts = new TextToSpeech(this, result -> {
            if(result != TextToSpeech.SUCCESS || tts == null) {
                updateTtsStatus("❌ TTS 초기화 실패 · 설정 > 일반 > 글자 읽어주기에서 엔진을 확인해 줘.");
                return;
            }
            int lang = tts.setLanguage(Locale.US);
            if(lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                updateTtsStatus("❌ 영어 음성 데이터가 없어. 글자 읽어주기 > 음성 데이터 설치 > 영어(미국)");
                return;
            }
            // Avoid rejecting the engine simply because getVoices() is empty.
            // Prefer an offline American English voice, then any offline English
            // voice. If the system default is already offline, keep it.
            Voice best = null;
            Set<Voice> voices = tts.getVoices();
            if(voices != null) {
                for(Voice v : voices) {
                    if(v == null || v.isNetworkConnectionRequired() || v.getLocale() == null) continue;
                    if(!"en".equals(v.getLocale().getLanguage())) continue;
                    if(best == null || ("US".equals(v.getLocale().getCountry()) &&
                            !"US".equals(best.getLocale().getCountry()))) best = v;
                }
            }
            String voiceInfo = "기본 영어 음성";
            if(best != null) {
                if(tts.setVoice(best) == TextToSpeech.SUCCESS) voiceInfo = "오프라인 영어 음성";
            }
            Voice selected = tts.getVoice();
            if(selected != null && selected.isNetworkConnectionRequired()) {
                updateTtsStatus("❌ 현재 영어 목소리는 인터넷이 필요해. 무료 오프라인 영어 음성 데이터를 설치해 줘.");
                return;
            }
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(true); updateTtsStatus("🔊 영어 음성 재생 중..."); });
                }
                @Override public void onDone(String id) {
                    runOnUiThread(() -> { avatar.setSpeaking(false); updateTtsStatus("✅ 영어 음성 재생 완료"); });
                }
                @Override public void onError(String id) { showTtsError("엔진 출력 오류"); }
                @Override public void onError(String id, int code) { showTtsError("엔진 오류 코드 " + code); }
                private void showTtsError(String detail) {
                    runOnUiThread(() -> {
                        avatar.setSpeaking(false);
                        updateTtsStatus("❌ 영어 음성 실패: " + detail + " · 영어 데이터/미디어 음량을 확인해 줘.");
                    });
                }
            });
            ttsReady = true;
            AudioManager am = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if(am != null && am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) {
                updateTtsStatus("⚠️ 미디어 음량이 0이야. 볼륨 버튼으로 올려 줘.");
            } else {
                updateTtsStatus("✅ " + voiceInfo + " 준비 완료 · 아래 '영어 음성 테스트'를 눌러 봐.");
            }
            if(speakTestAfterInit) {
                speakTestAfterInit = false;
                runOnUiThread(() -> speak("Hello! I am Lumi. Can you hear my voice?"));
            }
        });
    }
    private void speak(String sentence) {
        if(!ttsReady || tts == null) {
            updateTtsStatus("❌ TTS가 준비되지 않았어. 영어 음성 테스트/엔진 재확인을 눌러 줘.");
            return;
        }
        tts.setSpeechRate(speed);
        int result = tts.speak(sentence, TextToSpeech.QUEUE_FLUSH, null,
                "lumi_"+System.currentTimeMillis());
        if(result == TextToSpeech.ERROR) {
            updateTtsStatus("❌ TTS 음성 요청 실패 · 글자 읽어주기 설정에서 영어(미국)를 확인해 줘.");
        }
    }
    private void requestCamera(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)enableCamera();
        else cameraPermission.launch(Manifest.permission.CAMERA);
    }
    private void enableCamera() {
        cameraEnabled=true;cameraToggle.setText("카메라 끄기");cameraPlaceholder.setVisibility(View.GONE);
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(!cameraEnabled)return;
            try{
                cameraProvider=future.get();cameraProvider.unbindAll();
                Preview preview=new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview);
                mark("내 얼굴 표시 중 · 영상 저장 없음");
            }catch(Exception e){cameraEnabled=false;cameraPlaceholder.setVisibility(View.VISIBLE);
                cameraToggle.setText("카메라 켜기");mark("전면 카메라 시작 실패: "+e.getClass().getSimpleName());}
        },ContextCompat.getMainExecutor(this));
    }
    private void disableCamera(){cameraEnabled=false;if(cameraProvider!=null)cameraProvider.unbindAll();
        cameraPlaceholder.setVisibility(View.VISIBLE);cameraToggle.setText("카메라 켜기");mark("카메라 꺼짐 · 영상 저장 없음");}

    /** On-device Android recognition. Never silently falls back to a network STT service. */
    private Intent recognitionIntent() {
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,koreanInput?"ko-KR":"en-US");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        return i;
    }
    private void requestMicrophone(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)beginRecognition();
        else micPermission.launch(Manifest.permission.RECORD_AUDIO);
    }
    private void beginRecognition(){
        if(Build.VERSION.SDK_INT<31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)){
            mark("기기 내 음성 인식 서비스가 없어. 기기 설정에서 오프라인 음성 인식을 설치해 줘.");
            showOfflineSpeechHelp(false);return;
        }
        stopRecognition(); // Only tear down a completed/previous session, not this recording.
        if(tts!=null)tts.stop();
        manuallyFinishedMic=false;micResultHandled=false;waitingForMicResult=false;
        partialMicText="";draftBeforeMic=input.getText().toString();
        final int session=++micSession;
        final boolean originalLanguage=koreanInput;
        try{
            recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle p){if(session==micSession)mark("🎤 듣고 있어… "+(originalLanguage?"한국어":"영어")+"로 말해 줘.");}
                @Override public void onBeginningOfSpeech(){if(session==micSession)mark("말씀을 인식 중이야. 끝나면 자동으로 보낼게.");}
                @Override public void onRmsChanged(float r){}
                @Override public void onBufferReceived(byte[] b){}
                @Override public void onEndOfSpeech(){if(session==micSession){waitingForMicResult=true;isListening=false;
                    microphoneButton.setText("변환 중…");mark("말한 내용을 확인하고 있어…");}}
                @Override public void onError(int code){
                    if(session!=micSession)return;
                    String result=partialMicText.trim();
                    boolean shouldSend=manuallyFinishedMic&&!result.isEmpty();
                    endRecognizerSession();
                    if(shouldSend){mark("마지막 인식 문장으로 전달할게.");deliverRecognized(result);return;}
                    if(code==SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE||code==SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED){
                        mark((originalLanguage?"한국어":"영어")+" 오프라인 음성 모델을 사용할 수 없어 ("+code+").");
                        showOfflineSpeechHelp(true);return;
                    }
                    String reason=code==SpeechRecognizer.ERROR_NO_MATCH?"음성을 정확히 알아듣지 못했어.":
                        code==SpeechRecognizer.ERROR_SPEECH_TIMEOUT?"말소리를 감지하지 못했어.":
                        code==SpeechRecognizer.ERROR_RECOGNIZER_BUSY?"마이크 인식 서비스가 사용 중이야.":
                        code==SpeechRecognizer.ERROR_AUDIO?"마이크 녹음 오류가 발생했어.":
                        code==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS?"마이크 권한을 확인해 줘.":
                        "음성 인식 오류 코드 "+code;
                    mark(reason+" 인식 결과가 있으면 입력창에 남아 있어. 다시 시도해 줘.");
                }
                @Override public void onResults(Bundle b){
                    if(session!=micSession||micResultHandled)return;
                    ArrayList<String> result=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String recognized=(result!=null&&!result.isEmpty())?result.get(0).trim():partialMicText.trim();
                    endRecognizerSession();
                    if(recognized.isEmpty())mark("음성 인식 결과가 없어. 다시 말해 줘.");
                    else deliverRecognized(recognized);
                }
                @Override public void onPartialResults(Bundle b){
                    if(session!=micSession)return;
                    ArrayList<String> results=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(results!=null&&!results.isEmpty()&&!results.get(0).trim().isEmpty()){
                        partialMicText=results.get(0).trim();
                        input.setText(partialMicText);
                        input.setSelection(input.length());
                        mark("인식 중: "+partialMicText);
                    }
                }
                @Override public void onEvent(int type, Bundle p){}
            });
            isListening=true; microphoneButton.setText("⏹ 말하기 끝내기");
            mark("마이크 연결 중… "+(originalLanguage?"한국어":"영어")+"로 말해 줘.");
            recognizer.startListening(recognitionIntent());
        }catch(Exception e){endRecognizerSession();mark("마이크 시작 실패: "+e.getClass().getSimpleName()+" · "+e.getMessage());}
    }
    /** Tapping the microphone again must finalize, NEVER cancel and discard speech. */
    private void finishRecognition(){
        if(!isListening||recognizer==null)return;
        manuallyFinishedMic=true;isListening=false;waitingForMicResult=true;
        microphoneButton.setText("변환 중…");mark("말하기 종료 · AI에 전달할 문장 확인 중…");
        try{recognizer.stopListening();}catch(Exception e){
            String value=partialMicText;endRecognizerSession();if(!value.isEmpty())deliverRecognized(value);
        }
        final int session=micSession;
        ui.postDelayed(()->{
            // Some device recognizers never send onResults after stopListening.
            // Preserve and submit the partial text rather than silently losing it.
            if(session!=micSession||!waitingForMicResult||micResultHandled)return;
            String recognized=partialMicText.trim();
            endRecognizerSession();
            if(!recognized.isEmpty())deliverRecognized(recognized);
            else mark("인식 결과가 없어. 한 번 더 말하거나 입력창에 적어 줘.");
        },3000);
    }
    private void deliverRecognized(String recognized){
        if(recognized==null||recognized.trim().isEmpty())return;
        input.setText(recognized.trim());input.setSelection(input.length());
        if(!gemma.isReady()||generating||gemma.isBusy()){
            if(generating||gemma.isBusy()) queuedVoiceMessage=recognized.trim();
            mark(!gemma.isReady()?"음성 인식 완료! AI를 시작하면 입력창의 질문을 보낼 수 있어.":
                "음성 인식 완료! 현재 답변 다음에 자동으로 질문할게.");
            return;
        }
        input.setText("");
        mark("음성 인식 완료 · AI에게 질문을 전달했어.");
        handleUser(recognized.trim());
    }
    private void endRecognizerSession(){
        micResultHandled=true;isListening=false;waitingForMicResult=false;
        if(microphoneButton!=null)microphoneButton.setText("🎤 말하기");
        if(recognizer!=null){try{recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
        micSession++;
    }
    private void stopRecognition(){
        micSession++;isListening=false;waitingForMicResult=false;micResultHandled=true;
        if(microphoneButton!=null)microphoneButton.setText("🎤 말하기");
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
    }
    private void showOfflineSpeechHelp(boolean canDownload){
        new AlertDialog.Builder(this)
            .setTitle((koreanInput?"한국어":"영어")+" 오프라인 음성 인식")
            .setMessage("EPLS는 음성 파일을 서버에 보내지 않기 위해 기기 내 음성 인식만 사용해. " +
                "휴대폰/태블릿의 음성 인식 서비스와 해당 언어팩이 필요해. " +
                "언어팩 다운로드를 시도하거나 Android 설정에서 오프라인 음성 인식 언어를 설치한 다음 다시 말해 줘.")
            .setNegativeButton("닫기",(d,w)->{})
            .setPositiveButton(canDownload&&Build.VERSION.SDK_INT>=33?"무료 언어팩 다운로드":"확인",
                (d,w)->{if(canDownload&&Build.VERSION.SDK_INT>=33)downloadSpeechLanguagePack();})
            .show();
    }
    private void downloadSpeechLanguagePack(){
        if(Build.VERSION.SDK_INT<33||!SpeechRecognizer.isOnDeviceRecognitionAvailable(this))return;
        try{
            if(downloadRecognizer!=null){downloadRecognizer.destroy();downloadRecognizer=null;}
            downloadRecognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            final SpeechRecognizer pending=downloadRecognizer;
            if(Build.VERSION.SDK_INT>=34){
                pending.triggerModelDownload(recognitionIntent(),getMainExecutor(),new ModelDownloadListener(){
                    @Override public void onProgress(int percent){mark("오프라인 언어팩 다운로드 "+percent+"%");}
                    @Override public void onSuccess(){mark("음성 언어팩 준비 완료! 다시 마이크를 눌러 줘.");releaseDownloadRecognizer(pending);}
                    @Override public void onScheduled(){mark("언어팩 다운로드가 예약됐어. 완료 후 마이크를 다시 눌러 줘.");releaseDownloadRecognizer(pending);}
                    @Override public void onError(int code){mark("언어팩 다운로드 오류 "+code+" · 기기 설정에서 직접 설치해 줘.");releaseDownloadRecognizer(pending);}
                });
            }else{
                pending.triggerModelDownload(recognitionIntent());
                mark("언어팩 다운로드를 요청했어. 설치 후 마이크를 다시 눌러 줘.");
                ui.postDelayed(()->releaseDownloadRecognizer(pending),30000);
            }
        }catch(Exception e){mark("언어팩 설치 요청 실패: "+e.getClass().getSimpleName());
            if(downloadRecognizer!=null){downloadRecognizer.destroy();downloadRecognizer=null;}}
    }
    private void releaseDownloadRecognizer(SpeechRecognizer item){
        if(downloadRecognizer==item){try{downloadRecognizer.destroy();}catch(Exception ignored){}downloadRecognizer=null;}
    }
    @Override protected void onResume(){super.onResume();if(cameraEnabled&&cameraProvider!=null)enableCamera();if(downloadId!=-1L){ui.removeCallbacks(progressPoll);progressPoll=this::pollDownload;ui.post(progressPoll);}}
    @Override protected void onPause(){super.onPause();if(cameraProvider!=null)cameraProvider.unbindAll();stopRecognition();if(tts!=null)tts.stop();avatar.setSpeaking(false);if(progressPoll!=null)ui.removeCallbacks(progressPoll);}
    @Override protected void onDestroy(){disableCamera();stopRecognition();if(tts!=null){tts.stop();tts.shutdown();}if(gemma!=null)gemma.shutdown();if(progressPoll!=null)ui.removeCallbacks(progressPoll);
        if(downloadRecognizer!=null){try{downloadRecognizer.destroy();}catch(Exception ignored){}downloadRecognizer=null;}
        super.onDestroy();}
}
