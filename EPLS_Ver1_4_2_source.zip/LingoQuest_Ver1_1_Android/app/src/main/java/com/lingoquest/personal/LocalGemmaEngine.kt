package com.lingoquest.personal

import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.Message
import java.util.concurrent.atomic.AtomicBoolean
import java.io.File
import java.util.concurrent.Executors

/**
 * Private, offline Gemma 4 E2B inference. This class contains no API endpoint, OAuth,
 * account/session access, telemetry, or metered cloud inference.
 * One background thread owns all LiteRT-LM operations (including shutdown).
 */
class LocalGemmaEngine {
    interface Callback {
        fun onReady()
        fun onReply(englishInput: String, englishReply: String)
        fun onPartialReply(englishInput: String, fullEnglishSoFar: String)
        fun onTranslation(korean: String)
        fun onError(reason: String)
    }

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var ready = false
    @Volatile private var busy = false
    @Volatile private var closed = false
    private var engine: Engine? = null
    private var dialogue: Conversation? = null
    @Volatile private var activeBackend: String = "CPU"
    fun backendName(): String = activeBackend

    fun isReady(): Boolean = ready
    fun isBusy(): Boolean = busy

    fun load(modelPath: String, callback: Callback) {
        if (closed) return
        if (busy) { callback.onError("AI가 다른 작업을 처리 중이야."); return }
        busy = true
        worker.execute {
            try {
                val f = File(modelPath)
                require(f.isFile && f.length() > 2_300_000_000L) { "Gemma 4 모델 파일이 없거나 다운로드가 불완전해." }
                closeModel()
                // Prefer accelerated prefill; fall back to the same model on CPU.
                // This changes hardware execution, NOT weights or answer sampling.
                val candidate = try {
                    val gpu = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.GPU()))
                    gpu.initialize()
                    activeBackend = "GPU"
                    gpu
                } catch (_: Throwable) {
                    val cpu = Engine(EngineConfig(modelPath = f.absolutePath, backend = Backend.CPU()))
                    cpu.initialize()
                    activeBackend = "CPU"
                    cpu
                }
                engine = candidate
                dialogue = candidate.createConversation(
                    ConversationConfig(systemInstruction = Contents.of(
                        "You are Lumi, a kind and engaging English conversation partner for a Korean teen. " +
                        "Reply in precise, natural and engaging English. Match response depth to the question: " +
                        "give a complete thoughtful explanation whenever it is called for, without an artificial sentence limit. " +
                        "For a conversational turn, respond naturally and keep the discussion going with a relevant follow-up when appropriate. " +
                        "Be safe, respectful, encouraging. Do not fabricate details about the student. " +
                        "If their English has a significant error, gently model the correct form without lecturing. " +
                        "Never disclose private account information. " +
                        "Do not include Korean translations unless explicitly requested in a separate task."
                    ), maxOutputToken = 1024)
                )
                ready = true
                if (!closed) callback.onReady()
            } catch (e: Throwable) {
                ready = false
                if (!closed) callback.onError("모델 실행 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    fun chat(original: String, isKorean: Boolean, callback: Callback) {
        if (!ready || closed) { callback.onError("먼저 무료 Gemma 4 모델을 로드해 줘."); return }
        if (busy) { callback.onError("AI가 답변 중이야. 잠시 후 다시 말해 줘."); return }
        busy = true
        worker.execute {
            try {
                val e = requireNotNull(engine)
                val d = requireNotNull(dialogue)
                // Keep the separate translation step for fidelity to the student's Korean.
                // Do not shorten the learner's message just to gain speed.
                val englishInput = if (isKorean) oneShot(
                    e,
                    "You are a Korean-to-English translator for a teenager. Translate into natural, accurate conversational English. Return only the translation. Do not answer the question.",
                    original
                ) else original
                val collected = StringBuilder()
                val finished = AtomicBoolean(false)
                d.sendMessageAsync(englishInput, object : MessageCallback {
                    override fun onMessage(message: Message) {
                        if (finished.get() || closed) return
                        val chunk = message.toString()
                        if (chunk.isEmpty()) return
                        val full = synchronized(collected) {
                            collected.append(chunk)
                            collected.toString()
                        }
                        callback.onPartialReply(englishInput, full)
                    }

                    override fun onDone() {
                        if (!finished.compareAndSet(false, true)) return
                        busy = false
                        if (closed) return
                        val full = synchronized(collected) { collected.toString().trim() }
                        if (full.isNotEmpty()) callback.onReply(englishInput, full)
                        else callback.onError("AI 답변이 비어 있어. 다시 시도해 줘.")
                    }

                    override fun onError(throwable: Throwable) {
                        if (!finished.compareAndSet(false, true)) return
                        busy = false
                        if (!closed) callback.onError("AI 답변 실패: " + safe(throwable))
                    }
                })
            } catch (e: Throwable) {
                busy = false
                if (!closed) callback.onError("AI 답변 실패: " + safe(e))
            }
        }
    }

    /** Translation is requested only when user taps the Korean meaning button. */
    fun translate(english: String, callback: Callback) {
        if (!ready || closed) { callback.onError("AI 모델이 로드되지 않았어."); return }
        if (busy) { callback.onError("AI 작업이 끝난 뒤 해석해 줘."); return }
        busy = true
        worker.execute {
            try {
                val result = oneShot(
                    requireNotNull(engine),
                    "Translate the following English conversation reply to clear, natural Korean for a teenage English learner. Translate only; no notes, no extra English.",
                    english
                )
                if (!closed) callback.onTranslation(result)
            } catch (e: Throwable) {
                if (!closed) callback.onError("번역 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    fun reset(callback: Callback) {
        if (!ready || closed) return
        if (busy) { callback.onError("대화가 진행 중이야."); return }
        busy = true
        worker.execute {
            try {
                dialogue?.close()
                dialogue = requireNotNull(engine).createConversation(
                    ConversationConfig(systemInstruction = Contents.of(
                        "You are Lumi, a friendly English conversational tutor for a Korean teenager. " +
                        "Reply in natural, accurate English with enough depth for the student's question; do not impose a sentence limit. " +
                        "Keep the conversation going with a relevant question where appropriate. " +
                        "Gently model corrections when appropriate. Never claim to know private facts."
                    ), maxOutputToken = 1024)
                )
                if (!closed) callback.onReady()
            } catch (e: Throwable) {
                if (!closed) callback.onError("대화 초기화 실패: " + safe(e))
            } finally { busy = false }
        }
    }

    private fun oneShot(e: Engine, instruction: String, input: String): String {
        e.createConversation(ConversationConfig(systemInstruction = Contents.of(instruction))).use { c ->
            return c.sendMessage(input).toString().trim().also {
                require(it.isNotEmpty()) { "모델의 결과가 비어 있어." }
            }
        }
    }

    private fun closeModel() {
        ready = false
        // Each resource closed at most once on the owner thread.
        val oldConversation = dialogue; dialogue = null
        val oldEngine = engine; engine = null
        try { oldConversation?.close() } catch (_: Throwable) {}
        try { oldEngine?.close() } catch (_: Throwable) {}
    }

    fun shutdown() {
        closed = true
        worker.execute { closeModel() }
        worker.shutdown()
    }

    private fun safe(e: Throwable): String =
        (e.message ?: e.javaClass.simpleName).take(240)
}
